<?php
include 'connection.php';
error_reporting(0);

$adminname =     $_POST['adminname'];
 $pass=   $_POST['password'];

echo "<br>";
echo "admin name is -> ".$adminname;
echo "<br>";
echo "password is -> ".$pass;
echo "<br>";

$sql= "SELECT * FROM admins WHERE username='$adminname'";
$query = mysqli_query($conn,$sql);
$row['id'] = mysqli_fetch_assoc($query);
$adminid = $row['id'];

if ($adminid) {
    echo "username is already exists ... plz try again .. :( ";
    echo "<br>";
} else {
    $sql2= "INSERT INTO `admins` (`id`, `username`, `passwords`) VALUES (NULL, '$adminname', '$pass')";
$query2 = mysqli_query($conn,$sql2);

if ($query2) {
   echo "new admin has been created ... ";
   echo "<br>";
} else {
    echo "plz try again :( ";
    echo "<br>";
}


}


?>
<html>
    <body>
        
    <font style="font-size:20px;">
                plz wait for 3 seconds .... 
        </font>
        <br>
        <br>

    <script>
         setTimeout(function(){
            window.location.href = 'admin.html';
         }, 3000);
      </script>
  
    </body>
</html>

