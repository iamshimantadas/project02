<?php
include 'connection.php';

 $username =    $_POST['adminid'];
 $pass =   $_POST['password'];

    $authsql="SELECT * FROM admins WHERE username='$username' AND passwords='$pass'";
$query =  mysqli_query($conn,$authsql);


$row = mysqli_fetch_assoc($query);

        if ($row['username']) {
            echo "your login successful .... ";
           
            header("Location:admincontrolpannel.php");

        } else {
            echo "invalid login , plz enter correct userid and password :( ";
        }
        
?>

<html>
    <body>
        
    <font style="font-size:20px;">
                plz wait for 3 seconds .... 
        </font>
        <br>
        <br>

    <script>
         setTimeout(function(){
            window.location.href = 'admin.html';
         }, 3000);
      </script>
  
    </body>
</html>
