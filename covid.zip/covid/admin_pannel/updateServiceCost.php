<?php
include 'connection.php';
error_reporting(0);


$PerDayCost =     $_POST['perdaycost'];
  $NoralServ =   $_POST['normalservcost'];
  $SpecialServ =  $_POST['specialservcost'];
  $GenWard  =  $_POST['genward'];
  $CasualWard =  $_POST['casualward'];
 $SemiSpecialWard =    $_POST['semispecialward'];
  $SpecialWard =   $_POST['specialward'];
 $DeluxeWard =   $_POST['deluxeward'];
 $Ccu =    $_POST['ccu'];
 $Iccu =   $_POST['iccu'];
 $Sicu=   $_POST['sicu'];
 $Burdward=   $_POST['burnward'];
  $Nicu=  $_POST['nicu'];
  $Picu =  $_POST['picu'];
  $Sgst=  $_POST['sgst'];
  $Cgst=  $_POST['cgst'];


  /*
  echo $PerDayCost;
echo "<br>";
echo $NoralServ;
echo "<br>";
echo $SpecialServ;
echo "<br>";
echo $GenWard;
echo "<br>";
echo $CasualWard;
echo "<br>";
echo $SemiSpecialWard;
echo "<br>";
echo $SpecialWard;
echo "<br>";
echo $DeluxeWard;
echo "<br>";
echo $Ccu;
echo "<br>";
echo $Iccu;
echo "<br>";
echo $Sicu;
echo "<br>";
echo $Burdward;
echo "<br>";
echo $Nicu;
echo "<br>";
echo $Picu;
echo "<br>";
echo $Sgst;
echo "<br>";
echo $Cgst;
echo "<br>";

  */
  echo "<br>";

  $sql = "TRUNCATE TABLE cost";
  $query = mysqli_query($conn,$sql);

  if ($query) {
      echo "old record deleted successfully ... ";
      $updateSql = "INSERT INTO `cost` (`enrollno`, `perday`, `specialserv`, `normalserv`, `genward`, `casuward`, `semispecward`, `specward`, `delaxward`, `ccu`, `iccu`, `sicu`, `burnward`, `nicuward`, `picuward`, `sgst`, `cgst`) VALUES (NULL, '$PerDayCost', '$SpecialServ', '$NoralServ', '$GenWard', '$CasualWard', '$SemiSpecialWard', '$SpecialWard', '$DeluxeWard', '$Ccu', '$Iccu', '$Sicu', '$Burdward', '$Nicu', '$Picu', '$Sgst', '$Cgst')";
      $query2 = mysqli_query($conn,$updateSql);
      if ($query2) {
          echo "new record updated ... ";
          echo "<br>";
      } else {
         echo "plz try again ... new record doesn't updated ... ";
         echo "<br>";
      }
      
  } else {
    echo "plz try again :(  ";
  }
  

?>


<html>
    <body>
        
    <font style="font-size:20px;">
                plz wait for 5 seconds .... 
        </font>
        <br>
        <br>

    <script>
         setTimeout(function(){
            window.location.href = 'admincontrolpannel.php';
         }, 5000);
      </script>
  
    </body>
</html>
