
<html>
    <body>
        
    <font style="font-size:20px;">
                plz wait for 5 seconds .... 
        </font>
        <br>
        <br>

    <script>
         setTimeout(function(){
            window.location.href = 'admincontrolpannel.php';
         }, 5000);
      </script>
  
    </body>
</html>

<?php

include 'connection.php';

 $prinumber=   $_POST['prinumber'];
 $patientname=   $_POST['patientname'];


$sql11 = "SELECT * FROM `newpatientregister` WHERE priphone='$prinumber' AND name='$patientname'";

$mysqli = $conn;

$query = $sql11;

echo '<table border="2px" cellspacing="2" cellpadding="2"> 
      <tr> 
          <td> <font face="Arial">Patient id</font> </td> 
          <td> <font face="Arial">Patient name</font> </td> 
          <td> <font face="Arial">Phone 1</font> </td> 
          <td> <font face="Arial">Phone 2</font> </td> 
          <td> <font face="Arial">Email</font> </td> 
          <td> <font face="Arial">Address</font> </td> 
          <td> <font face="Arial">Location</font> </td> 
          <td> <font face="Arial">Pincode</font> </td> 
          <td> <font face="Arial">DOB</font> </td> 
          <td> <font face="Arial">Age</font> </td> 
          <td> <font face="Arial">Image</font> </td> 
         
 </tr>';

if ($result = $mysqli->query($query)) {
    while ($row = $result->fetch_assoc()) {
        $field1name = $row["enrollid"];
        $field2name = $row["name"];
        $field3name = $row["priphone"];
        $field4name = $row["secphone"];
        $field5name = $row["emailaddr"];
        $field6name = $row["residentaddr"];
        $field7name = $row["loc"];
        $field8name = $row["pincode"];
        $field9name = $row["dob"];
        $field10name = $row["age"];
        $field11ame = $row["profile"];
      

        echo '<tr> 
                  <td>'.$field1name.'</td> 
                  <td>'.$field2name.'</td> 
                  <td>'.$field3name.'</td> 
                  <td>'.$field4name.'</td> 
                  <td>'.$field5name.'</td>
                  <td>'.$field6name.'</td>
                  <td>'.$field7name.'</td>
                  <td>'.$field8name.'</td>
                  <td>'.$field9name.'</td>
                  <td>'.$field10name.'</td>
                  <td>'.'<img src="data:image/jpeg;base64,'.base64_encode($row['profile']).'" height="100" width="100"/>'.'</td>
                
                  </tr>';
    }
    $result->free();
} 

?>
