<html lang="en">
    <head>
      <!-- Required meta tags -->
      <meta charset="utf-8">
      <meta name="viewport" content="width=device-width, initial-scale=1">
      <link rel="icon" type="image/png" href="adminlogo.png">
  
      <!-- Bootstrap CSS -->
      <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
  
      <title>admin control pannel</title>
    </head>
    <body>
  
    <br>
  <?php
  include 'connection.php';
  
  $_SESSION["adminloggedin"] = "validlogin";
  
  
  
  ?>
  <br>
  <br>
   
<div class="container">
<div class="row">
        <div class="col-4">
            <font style="font-size:20px;">
          <b>
              upload new covid report of all over India
          </b>
          </font>
          <br>
          <br>
          <a href="indiaReport.html">
          <button type="button" class="btn btn-outline-dark">update now</button>
          </a>
        </div>
        <div class="col-4">
        <font style="font-size:20px;">
          <b>
              upload new covid report of all states of India
          </b>
          </font>
          <br>
          <br>
          <a href="stateReport.html">
          <button type="button" class="btn btn-outline-dark">update now</button>
          </a>
        </div>
        <div class="col-4">
        <font style="font-size:20px;">
          <b>
              upload new covid report of all over world
          </b>
          </font>
          <br>
          <br>
          <a href="worldReport.html">
          <button type="button" class="btn btn-outline-dark">update now</button>
          </a>
        </div>
    </div>
  <br>
  
  <br>

<div class="row">
  <div class="col-4">
    <img src="bedallot.png" class="img-thumbnail" alt="..." style="max-height:100px;max-width:100px;">
          <br>
          <a href="bedAdmits.html">
          <button type="button" class="btn btn-primary">New patint admits & bed allot </button>
          </a>
  
  </div>
  <div class="col-4">
    <img src="freebed.jpg" class="img-thumbnail" alt="..." style="max-height:100px;max-width:100px;">
          <br>
          <a href="freeBedAllot.html">
          <button type="button" class="btn btn-primary">Free bed allot</button>
          </a>
  
  </div>
  <div class="col-4">
    <img src="admitreq.jpg" class="img-thumbnail" alt="..." style="max-height:100px;max-width:100px;">
          <br>
          <a href="viewallAdmitsreq.php">
          <button type="button" class="btn btn-primary">view all admit requests</button>
          </a>
  
  
  </div>
</div>


  <br>
  
  <br>
  
  <div class="row">
    <div class="col-3">
      <img src="allBedStatus.jpg" class="img-thumbnail" alt="..." style="max-height:100px;max-width:100px;">
    <br>
       <a href="allBedStatus.php">
    <button type="button" class="btn btn-primary">all bed status</button>
    </a>
  
    </div>
    <div class="col-3">
      <img src="bedNoStatus.jpg" class="img-thumbnail" alt="..." style="max-height:100px;max-width:100px;">
    <br>
       <a href="bedNoStatus.html">
    <button type="button" class="btn btn-primary">bed no status</button>
    </a>
   
    </div>
    <div class="col-3">
      <img src="bookedBedLists.png" class="img-thumbnail" alt="..." style="max-height:100px;max-width:100px;">
    <br>
      <a href="bookedBedLists.php">
    <button type="button" class="btn btn-primary">booked bed lists</button>
    </a>
  
    </div>
    <div class="col-3">
      <img src="freeBedLists.png" class="img-thumbnail" alt="..." style="max-height:100px;max-width:100px;">
    <br>
      <a href="freeBedLists.php">
    <button type="button" class="btn btn-primary">free bed lists</button>
    </a>
  
    </div>
  </div>

  <br>
<br>

<div class="row">
  <font style="font-size:20px;">
    daily free test records ... 
  </font>
  <br>
  <div class="col-2"></div>
  <div class="col-4">
  <img src="allrecords.png" class="img-thumbnail" alt="..." style="max-height:100px;max-width:100px;">
    <br>
   
         <a href="dailyFreeTestRecordView.php">
           <button type="button" class="btn btn-info">all records</button>    </a>
    
  </div>
  <div class="col-4">
    <img src="sortbydate.png" class="img-thumbnail" alt="..." style="max-height:100px;max-width:100px;">
    <br>
 
             <a href="sortbydate.html">
            <button type="button" class="btn btn-info">sort by date</button>   </a>
 
  </div>
  <div class="col-2"></div>
  
</div>

  <br>
  <br>

<div class="row">
  <font style="font-size:20px;">
    isolation test records ... 
  </font>
  <br>
  <div class="col-3">
    <img src="allrecords.png" class="img-thumbnail" alt="..." style="max-height:100px;max-width:100px;">
    <br>
 
           <a href="viewAllIsolationRecords.php">
            <button type="button" class="btn btn-info">all reports</button>   </a>
 
  </div>
  <div class="col-3">
    <img src="sortname.png" class="img-thumbnail" alt="..." style="max-height:100px;max-width:100px;">
    <br>
 
         <a href="sortByNameIsolation.html">
           <button type="button" class="btn btn-info">patinet's name</button>    </a>
    
  </div>
  <div class="col-3">
    <img src="sortbydate.png" class="img-thumbnail" alt="..." style="max-height:100px;max-width:100px;">
    <br>
 
             <a href="sortBydateIsolation.html">
            <button type="button" class="btn btn-info">sort by date</button>   </a>
 
  </div>
  <div class="col-3">
    <img src="sortrecords.png" class="img-thumbnail" alt="..." style="max-height:100px;max-width:100px;">
    <br>
 
           <a href="sortbyIdIsolation.html">
            <button type="button" class="btn btn-info">sort by patinet's id</button>   </a>
 
  </div>
  
</div>


<br>
  <br>

<br>
<br>


<div class="container">
  
<div class="row">
    <div class="col-4">
        <img src="currency.jpg" class="img-thumbnail" alt="..." style="max-height:100px;max-width:100px;">
        <br>
     
      <a href="updateServiceCost.html">
        <button type="button" class="btn btn-danger">update costs</button>
        </a> 
    </div>
  <div class="col-4">
    <img src="manageadmins.png" class="img-thumbnail" alt="..." style="max-height:100px;max-width:100px;">
    <br>
 
  <a href="manageadmins.html">
    <button type="button" class="btn btn-danger">manage admins</button>
    </a> 
  </div>
  <div class="col-4">
    <img src="logoutuser.png" class="img-thumbnail" alt="..." style="max-height:100px;max-width:100px;">
    <br>
 
  <a href="logout.php">
    <button type="button" class="btn btn-danger">admin logout</button>
    </a> 
</div>

</div>

</div>

<br>
<br>

<!-- Optional JavaScript; choose one of the two! -->
  
      <!-- Option 1: Bootstrap Bundle with Popper -->
      <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-MrcW6ZMFYlzcLA8Nl+NtUVF0sA7MsXsP1UyJoMp4YLEuNSfAP+JcXn/tWtIaxVXM" crossorigin="anonymous"></script>
  
      <!-- Option 2: Separate Popper and Bootstrap JS -->
      <!--
      <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.9.2/dist/umd/popper.min.js" integrity="sha384-IQsoLXl5PILFhosVNubq5LC7Qb9DXgDA9i+tQ8Zj3iwWAwPtgFTxbJ8NT4GN1R8p" crossorigin="anonymous"></script>
      <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.min.js" integrity="sha384-cVKIPhGWiC2Al4u+LWgxfKTRIcfu0JTxR+EQDz/bgldoEyl4H0zUF0QKbrJ0EcQF" crossorigin="anonymous"></script>
      -->
    </body>
  </html>
