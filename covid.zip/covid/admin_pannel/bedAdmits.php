<?php
include 'connection.php';

$name=    $_POST['name'];
 $bedno=   $_POST['bedno'];
 $admitfrom=   $_POST['admitfrom'];
  $admitupto=  $_POST['admitupto'];
$servicereq=    $_POST['servicereq'];
 $wardtype=   $_POST['wardtype'];
 $covid19status =   $_POST['covid19'];
 $bedstatus = "BOOKED";

echo "<br>";
echo "patient's name is : ".$name;
echo "<br>";
echo "patient's bed no is : ".$bedno;
echo "<br>";
echo "patient's admit from : ".$admitfrom;
echo "<br>";
echo "patient's admit upto : ".$admitupto;
echo "<br>";
echo "patient's service request : ".$servicereq;
echo "<br>";
echo "patient's ward type : ".$wardtype;
echo "<br>";
echo "covid-19 status : ".$covid19status;
echo "<br>";
echo "bed status : ".$bedstatus;
echo "<br>";

$checksql="SELECT * FROM bedadmits WHERE bedno='$bedno'";
$query1= mysqli_query($conn,$checksql);
$row['bedno'] = mysqli_fetch_assoc($query1);
$bednoget = $row['bedno'];

if ($bednoget) {
  $sql11="UPDATE bedadmits SET `patientname` = '$name', `startdate` = '$admitfrom', `enddate` = '$admitupto',servicetype='$servicereq' ,wardtype='$wardtype',covid19='$covid19status',bedstatus = 'BOOKED' WHERE `bedno` = '$bedno'";
  $query2= mysqli_query($conn,$sql11);

if ($query2) {
  echo "<br>";
 echo "patient new bed status updated !! ";
} else {
  echo "<br>";
  echo "plz try again :( 1st query ";
}
} 
else 
{
  
$sql3="INSERT INTO `bedadmits` (`enrollno`, `patientname`, `startdate`, `enddate`, `bedno`, `servicetype`, `wardtype`, `covid19`, `bedstatus`) VALUES (NULL, '$name', '$admitfrom', '$admitupto', '$bedno', '$servicereq', '$wardtype', '$covid19status', '$bedstatus')";
$query2= mysqli_query($conn,$sql3);

if ($query2) {
  echo "<br>";
 echo "patient new bed has been alloted !! ";
} else {
  echo "<br>";
  echo "plz try again :( 2nd query ";
}

}


$sql4="INSERT INTO `admithistory` (`enrollno`, `patientname`, `startdate`, `enddate`, `bedno`, `servicetype`, `wardtype`, `covid19`, `bedstatus`) VALUES (NULL, '$name', '$admitfrom', '$admitupto', '$bedno', '$servicereq', '$wardtype', '$covid19status', '$bedstatus')";

$query3= mysqli_query($conn,$sql4);

if ($query3) {
  echo "<br>";
 echo "patient record also saved into our database permanently  !! ";
} 
else {
  echo "<br>";
  echo "plz try again :( third query ";
}


?>

<html>
    <body>
        <font style="font-size:20px;">
                plz wait for 5 seconds .... 
        </font>
        <br>
        <br>

    <script>
         setTimeout(function(){
            window.location.href = 'admincontrolpannel.php';
         }, 5000);
      </script>
     

    </body>
</html>