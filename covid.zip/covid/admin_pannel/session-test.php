<?php

session_start();


$sessionvar =   $_SESSION["adminloggedin"];

if ($sessionvar) {
    echo "session runnng";
} else {
    echo "session not runnng";
}

?>