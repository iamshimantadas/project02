<!DOCTYPE html>
<html>
<head>
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<style>
* {
  box-sizing: border-box;
}
.menu {
  float: left;
  width: 20%;
}
.menuitem {
  padding: 8px;
  margin-top: 7px;
  border-bottom: 1px solid #f1f1f1;
}
.main {
  float: left;
  width: 60%;
  padding: 0 20px;
  overflow: hidden;
}
.right {
  background-color: lightblue;
  float: left;
  width: 20%;
  padding: 10px 15px;
  margin-top: 7px;
}

@media only screen and (max-width:800px) {
  /* For tablets: */
  .main {
    width: 80%;
    padding: 0;
  }
  .right {
    width: 100%;
  }
}
@media only screen and (max-width:500px) {
  /* For mobile phones: */
  .menu, .main, .right {
    width: 100%;
  }
}
</style>
</head>
<body style="font-family:Verdana;" id="printable">

<?php
include 'connection.php';

error_reporting(0);

$bedno= $_POST['bedno'];

$checkBedExist = "SELECT * FROM bedadmits WHERE bedno='$bedno'";
$query1 = mysqli_query($conn,$checkBedExist);
while ($row = mysqli_fetch_assoc($query1)) {
    $PatientName = $row['patientname'];
    $dateStart = $row['startdate'];
    $dateEnd = $row['enddate'];
    $service = $row['servicetype'];
    $ward = $row['wardtype'];
    
}

echo "patinet's name is : ".$PatientName;
echo "<br>";
echo "patient's start date of admit : ".$dateStart;
echo "<br>";
echo "patient's end date of admit : ".$dateEnd;
echo "<br>";
echo "patient's service type : ".$service;
echo "<br>";
echo "patient's ward type : ".$ward;
echo "<br>";

$date1 = date_create("$dateStart");
$date2 = date_create("$dateEnd");
$diff = date_diff($date1,$date2);

echo $diff->format("patient stays for %a days");
echo "<br>";

$stayDays = $diff->format("%a");


$sql2 = "SELECT * FROM cost";
$query2 = mysqli_query($conn,$sql2);
while ($row1 = mysqli_fetch_assoc($query2)) {
    $perdaycost = $row1['perday'];
    $SpecialserviceCharge =  $row1['specialserv'];
    $NormalserviceCharge =  $row1['normalserv'];
  $GENWARD   =  $row1['genward'];
  $CASUALWARD =  $row1['casuward'];
  $SEMISPECIALWARD = $row1['semispecward'];
  $SPECIALWARD =  $row1['specward'];
  $DELUXEWARD =  $row1['delaxward'];
 $CCU =   $row1['ccu'];
 $ICCU =  $row1['iccu'];
 $SICU =  $row1['sicu'];
 $BURNWARD =   $row1['burnward'];
$NICU =    $row1['nicuward'];
 $PICU =   $row1['picuward'];
$SGST =    $row1['sgst'];
 $CGST =   $row1['cgst'];
}

if ($PatientName) {
    echo "bed has been identified ... ";
    echo "<br>";



    // calculating the cost of living daily of patient ... 
    $sum1 = $perdaycost*$stayDays;

// calculating the cost of servie type ... 
if ($service == "normal") {
    $servicechrg = $NormalserviceCharge;
}
if ($service == "specialcare") {
    $servicechrg = $SpecialserviceCharge;
}
$sum2 = $servicechrg;

// calculating cost of ward 

    if ($ward == "GENERAL WARD") {
        $genwardchange = $GENWARD;
    $sum3 = $genwardchange;
    }
    if ($ward == "CAUSALITY") {
        $casualwardchange = $CASUALWARD;
        $sum3 = $casualwardchange;
    }
    if ($ward == "SEMI-SPECIAL ROOM") {
        $semispecialwardchange = $SEMISPECIALWARD;
        $sum3 = $semispecialwardchange;
    }
    if ($ward == "SPECIAL WARDS") {
        $specialwardchange = $SPECIALWARD;
        $sum3= $specialwardchange;
    }
   
    if ($ward == "DELUXE ROOM") {
        $deluxeroomwardchange = $DELUXEWARD;
        $sum3 = $deluxeroomwardchange;
    }
    if ($ward == "CCU") {
        $ccuwardchange = $CCU;
        $sum3 = $ccuwardchange;
    }
    if ($ward == "ICCU") {
        $iccuwardchange = $ICCU;
        $sum3 = $iccuwardchange;
    }
    if ($ward == "SICU") {
        $sicuwardchange = $SICU;
        $sum3 = $sicuwardchange;
    }
    if ($ward == "BURN WARD") {
        $burnwardchange = $BURNWARD;
        $sum3 = $burnwardchange;
    }
    if ($ward == "NICU") {
        $nicuwardchange = $NICU;
        $sum3 = $nicuwardchange;
    }
    if ($ward == "PICU") {
        $picuwardchange = $PICU;
        $sum3 = $picuwardchange;
    }

    $gst = $SGST+$CGST;
   $sum4 = $gst;
   

   $total = $sum1+$sum2+$sum3+$sum4;
 
 
 echo "patient's living charge : ".$sum1;
   echo "<br>";
   echo "patient's care charge[service charge] : ".$sum2;
   echo "<br>";
   echo "patient's ward charge : ".$sum3;
   echo "<br>";
   echo "SGST[state govt. gst] : ".$SGST;
   echo "<br>";
   echo "CGST[central govt. gst] : ".$CGST;
   echo "<br>";
   echo "<br>";
   
   echo "patient's total bill is(GST included) : ".$total;
   echo "<br>";
   echo "<br>";
   echo "<br>";
  
   echo "we hope that you satisfied with our services ... ";
   echo "<br>";
   echo "Thank you ... ";
} else {
    echo "bed number can't identified ... ";
    echo "<br>";
}



$mysqli = $conn;


$freebedquery = "UPDATE bedadmits SET `patientname` = 'NOANY', `startdate` = '2022-01-01', `enddate` = '2022-01-01',servicetype='none' ,wardtype='none',covid19='none',bedstatus = 'FREE' WHERE `bedno` = '$bedno'";
$query3 = $freebedquery;
$free =  mysqli_query($conn,$query3);
if ($free) {
    echo "<br>";
    echo "free bed successfully successfully alloted .... ";
}

?>

<br>
<!-- convert pdf -->
<script src="jquery.js"></script>
<script src="html2canvas.js"></script>
<script src="debug-main.js"></script>

<button onClick="printToPDF();">
  download bill
</button>

<script>
    function printToPDF() {
  console.log('converting...');

  var printableArea = document.getElementById('printable');

  html2canvas(printableArea, {
    useCORS: true,
    onrendered: function(canvas) {

      var pdf = new jsPDF('p', 'pt', 'letter');

      var pageHeight = 980;
      var pageWidth = 900;
      for (var i = 0; i <= printableArea.clientHeight / pageHeight; i++) {
        var srcImg = canvas;
        var sX = 0;
        var sY = pageHeight * i; // start 1 pageHeight down for every new page
        var sWidth = pageWidth;
        var sHeight = pageHeight;
        var dX = 0;
        var dY = 0;
        var dWidth = pageWidth;
        var dHeight = pageHeight;

        window.onePageCanvas = document.createElement("canvas");
        onePageCanvas.setAttribute('width', pageWidth);
        onePageCanvas.setAttribute('height', pageHeight);
        var ctx = onePageCanvas.getContext('2d');
        ctx.drawImage(srcImg, sX, sY, sWidth, sHeight, dX, dY, dWidth, dHeight);

        var canvasDataURL = onePageCanvas.toDataURL("image/png", 1.0);
        var width = onePageCanvas.width;
        var height = onePageCanvas.clientHeight;

        if (i > 0) // if we're on anything other than the first page, add another page
          pdf.addPage(612, 791); // 8.5" x 11" in pts (inches*72)

        pdf.setPage(i + 1); // now we declare that we're working on that page
        pdf.addImage(canvasDataURL, 'PNG', 20, 40, (width * .62), (height * .62)); // add content to the page

      }
      pdf.save('bill.pdf');
    }
  });
}
</script>
<br>
<a href="admincontrolpannel.php">
<button style="background-color:blue;color:white;">
back to main page
</button>
</a>
<br>
<br>
        <br>
        <br>

    <script>
         setTimeout(function(){
            window.location.href = 'admincontrolpannel.php';
         }, 20000);
      </script>
</body>
</html>
