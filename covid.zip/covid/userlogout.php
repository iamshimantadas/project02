<?php
session_start();
// remove all session variables
session_unset();

// destroy the session
session_destroy(); 

echo "user logout got successfully .... ";

?>


<html>
    <body>
        <font style="font-size:20px;">
                plz wait for 5 seconds .... 
        </font>
        <br>
        <br>

    <script>
         setTimeout(function(){
            window.location.href = 'index.php';
         }, 5000);
      </script>
     

    </body>
</html>
