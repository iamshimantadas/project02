
<html>
    <body>
        <font style="font-size:20px;">
                plz wait for 5 seconds ....
        </font>
        <br>
        <br>

    <script>
         setTimeout(function(){
            window.location.href = 'index.php';
         }, 5000);
      </script>


    </body>
</html>


<?php
include 'connection.php';

session_start();

if ($_SESSION["userlogin"]) {
  # code...
} else {
  echo "plz do the login";
  header("Location: userlogin.html");
}


$patientid=     $_POST['patientid'];
 $name=   $_POST['name'];
 $roomstat=   $_POST['roomstatus'];
 $socaildis=   $_POST['socialdis'];
  $handwash=  $_POST['handwash'];
 $oxilvl=   $_POST['oxilevel'];
  $bodytemp=  $_POST['bodytemp'];
$dayofsubmit = date("Y/m/d");

/*
echo "<br>";
echo $patientid;
echo "<br>";
echo $name;
echo "<br>";
echo $roomstat;
echo "<br>";
echo $socaildis;
echo "<br>";
echo $handwash;
echo "<br>";
echo $oxilvl;
echo "<br>";
echo $bodytemp;
echo "<br>";
echo $dayofsubmit;
echo "<br>";

*/

  $sql1= "INSERT INTO `isolation` (`enrollno`, `patientid`, `patientname`, `roomstatus`, `socialdis`, `handwash`, `oxigenlvl`, `bodytemp`, `dayofreport`) VALUES (NULL, '$patientid', '$name', '$roomstat', '$socaildis', '$handwash', '$oxilvl', '$bodytemp', '$dayofsubmit')";
  $query =   mysqli_query($conn,$sql1);

  if ($query) {
     echo "patient isolation request submitted ...  we will respond you soon :) ";
  } else {
      echo "plz try again :( ";
  }

?>

