
<html>
    <body>
        <font style="font-size:20px;">
                plz wait for 5 seconds .... 
        </font>
        <br>
        <br>

    <script>
         setTimeout(function(){
            window.location.href = 'index.php';
         }, 5000);
      </script>
     

    </body>
</html>

<?php
include 'connection.php';

 $email =    $_POST['email'];
  $pass=   $_POST['password'];

 $sql="SELECT * FROM newpatientregister WHERE emailaddr='$email' AND passwords='$pass'";
$query = mysqli_query($conn,$sql);
$row = mysqli_fetch_assoc($query);


if ($row['enrollid']) {
    echo "user login get successful";


session_start();

$_SESSION["userlogin"] = "success";


} else {
    echo "plz try again :( , plz enter your correct email address and password ...  ";
}


?>
