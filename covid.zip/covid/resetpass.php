<?php
include 'connection.php';
error_reporting(0);

 $patientid =    $_POST['patientid'];
 $email =    $_POST['email'];
$prinumber =     $_POST['prinumber'];
  $oldpass =   $_POST['oldpass'];
$newpass=     $_POST['newpass'];
$newpass2 =     $_POST['newpass2'];

if ($newpass == $newpass2) {
    # code...
} else {
   echo "password d";
}



$sql= "SELECT * FROM newpatientregister WHERE enrollid='$patientid' AND emailaddr='$email' AND priphone='$prinumber' AND passwords='$oldpass'";
$query1 = mysqli_query($conn,$sql);
$row['name'] = mysqli_fetch_assoc($query1);
$patientname =  $row['name'];

if ($patientname) {
    echo "user detected successfully ... ";
    echo "<br>";
    $resetpass = "UPDATE newpatientregister SET passwords = '$newpass' WHERE enrollid = '$patientid'";
    $query2 = mysqli_query($conn,$resetpass);
    if ($query2) {
        echo "password reset successfully ... ";
        echo "<br>";
    } else {
        echo "password does't changed ... plz try again .. ";
        echo "<br>";
    }
    
} else {
    echo "<br>";
    echo "patient's information is not correct ... ";
}


?>


<html>
    <body>
        
    <font style="font-size:20px;">
                plz wait for 5 seconds .... 
        </font>
        <br>
        <br>

    <script>
         setTimeout(function(){
            window.location.href = 'userlogin.html';
         }, 5000);
      </script>
  
  
    </body>
</html>
