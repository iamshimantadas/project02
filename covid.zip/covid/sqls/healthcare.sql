-- Database: `healthcare`
--

-- --------------------------------------------------------

--
-- Table structure for table `admins`
--

CREATE TABLE `admins` (
  `id` bigint(20) NOT NULL,
  `username` varchar(200) NOT NULL,
  `passwords` varchar(100) NOT NULL
);

--
-- Dumping data for table `admins`
--

INSERT INTO `admins` (`id`, `username`, `passwords`) VALUES
(1, 'admin', 'admin123');

-- --------------------------------------------------------

--
-- Table structure for table `admithistory`
--

CREATE TABLE `admithistory` (
  `enrollno` bigint(20) NOT NULL,
  `patientname` varchar(200) NOT NULL,
  `startdate` date NOT NULL,
  `enddate` date NOT NULL,
  `bedno` bigint(20) NOT NULL,
  `servicetype` varchar(200) NOT NULL,
  `wardtype` varchar(200) NOT NULL,
  `covid19` varchar(200) NOT NULL,
  `bedstatus` varchar(100) DEFAULT NULL
);

-- --------------------------------------------------------

--
-- Table structure for table `admitreq`
--

CREATE TABLE `admitreq` (
  `enrollno` bigint(20) NOT NULL,
  `patientname` varchar(210) NOT NULL,
  `admitfrom` date NOT NULL,
  `admitupto` date NOT NULL,
  `servicetype` varchar(200) NOT NULL,
  `dayofsubmit` date NOT NULL,
  `phoneno` bigint(10) NOT NULL
);

-- --------------------------------------------------------

--
-- Table structure for table `bedadmits`
--

CREATE TABLE `bedadmits` (
  `enrollno` bigint(20) NOT NULL,
  `patientname` varchar(200) NOT NULL,
  `startdate` date NOT NULL,
  `enddate` date NOT NULL,
  `bedno` bigint(20) NOT NULL,
  `servicetype` varchar(200) NOT NULL,
  `wardtype` varchar(200) NOT NULL,
  `covid19` varchar(200) NOT NULL,
  `bedstatus` varchar(100) DEFAULT NULL
);

-- --------------------------------------------------------

--
-- Table structure for table `cost`
--

CREATE TABLE `cost` (
  `enrollno` bigint(200) NOT NULL,
  `perday` bigint(200) NOT NULL,
  `specialserv` bigint(200) NOT NULL,
  `normalserv` bigint(200) NOT NULL,
  `genward` bigint(200) NOT NULL,
  `casuward` bigint(200) NOT NULL,
  `semispecward` bigint(200) NOT NULL,
  `specward` bigint(200) NOT NULL,
  `delaxward` bigint(200) NOT NULL,
  `ccu` bigint(200) NOT NULL,
  `iccu` bigint(200) NOT NULL,
  `sicu` bigint(200) NOT NULL,
  `burnward` bigint(200) NOT NULL,
  `nicuward` bigint(200) NOT NULL,
  `picuward` bigint(200) NOT NULL,
  `sgst` bigint(200) NOT NULL,
  `cgst` bigint(200) DEFAULT NULL
);

-- --------------------------------------------------------

--
-- Table structure for table `dailyfreetest`
--

CREATE TABLE `dailyfreetest` (
  `enrollno` bigint(20) NOT NULL,
  `patientname` varchar(200) NOT NULL,
  `loc` varchar(200) NOT NULL,
  `pincode` bigint(20) NOT NULL,
  `phone` bigint(20) NOT NULL,
  `socialdis` varchar(210) NOT NULL,
  `sanitizetime` varchar(100) NOT NULL,
  `bodytemp` varchar(200) NOT NULL,
  `chestpain` varchar(200) NOT NULL,
  `reportdate` date NOT NULL
);

-- --------------------------------------------------------

--
-- Table structure for table `indiareport`
--

CREATE TABLE `indiareport` (
  `enrollno` bigint(20) NOT NULL,
  `active` varchar(200) NOT NULL,
  `activestatus` varchar(100) NOT NULL,
  `recovered` varchar(255) NOT NULL,
  `recoveredstatus` varchar(100) NOT NULL,
  `newsymp` varchar(200) NOT NULL,
  `newsympstatus` varchar(100) NOT NULL,
  `deadcase` varchar(200) NOT NULL,
  `deathstatus` varchar(100) NOT NULL,
  `dayofupload` date NOT NULL
);

--
-- Dumping data for table `indiareport`
--

INSERT INTO `indiareport` (`enrollno`, `active`, `activestatus`, `recovered`, `recoveredstatus`, `newsymp`, `newsympstatus`, `deadcase`, `deathstatus`, `dayofupload`) VALUES
(1, '56236', 'up', '4,25,02,454', 'down', '56236', 'up', '5,21,685', 'neutral', '2022-04-10');

-- --------------------------------------------------------

--
-- Table structure for table `isolation`
--

CREATE TABLE `isolation` (
  `enrollno` bigint(20) NOT NULL,
  `patientid` bigint(20) NOT NULL,
  `patientname` varchar(200) NOT NULL,
  `roomstatus` varchar(100) NOT NULL,
  `socialdis` varchar(100) NOT NULL,
  `handwash` varchar(100) NOT NULL,
  `oxigenlvl` varchar(100) NOT NULL,
  `bodytemp` int(11) NOT NULL,
  `dayofreport` date NOT NULL
);

-- --------------------------------------------------------

--
-- Table structure for table `newpatientregister`
--

CREATE TABLE `newpatientregister` (
  `enrollid` bigint(20) NOT NULL,
  `name` varchar(200) NOT NULL,
  `priphone` bigint(10) NOT NULL,
  `secphone` varchar(100) NOT NULL,
  `emailaddr` varchar(100) NOT NULL,
  `residentaddr` varchar(200) NOT NULL,
  `loc` varchar(200) NOT NULL,
  `pincode` bigint(10) NOT NULL,
  `dob` date NOT NULL,
  `age` int(11) NOT NULL,
  `profile` longblob NOT NULL,
  `passwords` varchar(100) DEFAULT NULL
);

-- --------------------------------------------------------

--
-- Table structure for table `statereport`
--

CREATE TABLE `statereport` (
  `enrollno` bigint(20) NOT NULL,
  `highcase` varchar(200) NOT NULL,
  `midcase` varchar(200) NOT NULL,
  `lowcase` varchar(200) NOT NULL,
  `dayofupload` date NOT NULL
);

--
-- Dumping data for table `statereport`
--

INSERT INTO `statereport` (`enrollno`, `highcase`, `midcase`, `lowcase`, `dayofupload`) VALUES
(1, 'Chhattisgarh,Andhra Pradesh,Madhya Pradesh', 'west bengal,oddisa,sikkim', 'arunachal pradesh,kerala', '2022-04-10');

-- --------------------------------------------------------

--
-- Table structure for table `worldreport`
--

CREATE TABLE `worldreport` (
  `enrollno` bigint(20) NOT NULL,
  `active` varchar(200) NOT NULL,
  `activestatus` varchar(100) NOT NULL,
  `recovered` varchar(255) NOT NULL,
  `recoveredstatus` varchar(100) NOT NULL,
  `newsymp` varchar(200) NOT NULL,
  `newsympstatus` varchar(100) NOT NULL,
  `deadcase` varchar(200) NOT NULL,
  `deathstatus` varchar(100) NOT NULL,
  `dayofupload` date NOT NULL
);

--
-- Dumping data for table `worldreport`
--

INSERT INTO `worldreport` (`enrollno`, `active`, `activestatus`, `recovered`, `recoveredstatus`, `newsymp`, `newsympstatus`, `deadcase`, `deathstatus`, `dayofupload`) VALUES
(1, '451236', 'up', '443,465,667', 'down', '451236', 'up', '6,201,853', 'neutral', '2022-04-10');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admins`
--
ALTER TABLE `admins`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `admithistory`
--
ALTER TABLE `admithistory`
  ADD PRIMARY KEY (`enrollno`);

--
-- Indexes for table `admitreq`
--
ALTER TABLE `admitreq`
  ADD PRIMARY KEY (`enrollno`);

--
-- Indexes for table `bedadmits`
--
ALTER TABLE `bedadmits`
  ADD PRIMARY KEY (`enrollno`);

--
-- Indexes for table `cost`
--
ALTER TABLE `cost`
  ADD PRIMARY KEY (`enrollno`);

--
-- Indexes for table `dailyfreetest`
--
ALTER TABLE `dailyfreetest`
  ADD PRIMARY KEY (`enrollno`);

--
-- Indexes for table `indiareport`
--
ALTER TABLE `indiareport`
  ADD PRIMARY KEY (`enrollno`);

--
-- Indexes for table `isolation`
--
ALTER TABLE `isolation`
  ADD PRIMARY KEY (`enrollno`);

--
-- Indexes for table `newpatientregister`
--
ALTER TABLE `newpatientregister`
  ADD PRIMARY KEY (`enrollid`);

--
-- Indexes for table `statereport`
--
ALTER TABLE `statereport`
  ADD PRIMARY KEY (`enrollno`);

--
-- Indexes for table `worldreport`
--
ALTER TABLE `worldreport`
  ADD PRIMARY KEY (`enrollno`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admins`
--
ALTER TABLE `admins`
  MODIFY `id` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `admithistory`
--
ALTER TABLE `admithistory`
  MODIFY `enrollno` bigint(20) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `admitreq`
--
ALTER TABLE `admitreq`
  MODIFY `enrollno` bigint(20) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `bedadmits`
--
ALTER TABLE `bedadmits`
  MODIFY `enrollno` bigint(20) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `cost`
--
ALTER TABLE `cost`
  MODIFY `enrollno` bigint(200) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `dailyfreetest`
--
ALTER TABLE `dailyfreetest`
  MODIFY `enrollno` bigint(20) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `indiareport`
--
ALTER TABLE `indiareport`
  MODIFY `enrollno` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `isolation`
--
ALTER TABLE `isolation`
  MODIFY `enrollno` bigint(20) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `newpatientregister`
--
ALTER TABLE `newpatientregister`
  MODIFY `enrollid` bigint(20) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `statereport`
--
ALTER TABLE `statereport`
  MODIFY `enrollno` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `worldreport`
--
ALTER TABLE `worldreport`
  MODIFY `enrollno` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
