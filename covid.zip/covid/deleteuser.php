<?php 
include 'connection.php';
error_reporting(0);

$patientid = 	$_POST['patientid'];
$emailid =	$_POST['email'];
$pass=	$_POST['password'];

echo "patient's id -> ".$patientid;
echo "<br>";
echo "emailid is -> ".$emailid;
echo "<br>";
echo "password is -> ".$pass;
echo "<br>";


$sql="SELECT * FROM newpatientregister WHERE enrollid='$patientid' AND emailaddr='$emailid' AND passwords='$pass'";
$query = mysqli_query($conn,$sql);
$row['name'] = mysqli_fetch_assoc($query);
$patientname = $row['name'];

if ($patientname) {
	echo "patinet has been identified ... ";
	echo "<br>";
	$deleteacc = "DELETE FROM newpatientregister WHERE enrollid='$patientid'";
	$query2 = mysqli_query($conn,$deleteacc);
	if ($query2) {
		echo "user account deleted successfully... ";
		echo "<br>";
	} else {
		echo "plz try again :( ";
		echo "<br>";
	}
	
} else {
	echo "patinet does not identified ... ";
	echo "<br>";
}


?>

<html>
    <body>
        
    <font style="font-size:20px;">
                plz wait for 5 seconds .... 
        </font>
        <br>
        <br>

    <script>
         setTimeout(function(){
            window.location.href = 'index.php';
         }, 5000);
      </script>
  
  
    </body>
</html>
