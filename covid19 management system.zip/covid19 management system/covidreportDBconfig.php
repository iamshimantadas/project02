<?php
$host="localhost";
$user="root";
$pass="";
$db="healthcare";
$covidrep = mysqli_connect($host,$user,$pass,$db);


if ($covidrep) {
  //  echo "covid database connected ... ";
}
error_reporting(0);

?>