CREATE TABLE `admins` (
  `id` bigint(20) NOT NULL,
  `username` varchar(200) NOT NULL,
  `passwords` varchar(100) NOT NULL
) ENGINE=InnoDB;

INSERT INTO `admins` (`id`, `username`, `passwords`) VALUES
(1, 'admin', 'admin123');


CREATE TABLE `admithistory` (
  `enrollno` bigint(20) NOT NULL,
  `patientname` varchar(200) NOT NULL,
  `startdate` date NOT NULL,
  `enddate` date NOT NULL,
  `bedno` bigint(20) NOT NULL,
  `servicetype` varchar(200) NOT NULL,
  `wardtype` varchar(200) NOT NULL,
  `covid19` varchar(200) NOT NULL,
  `bedstatus` varchar(100) DEFAULT NULL
)ENGINE=InnoDB;

CREATE TABLE `admitreq` (
  `enrollno` bigint(20) NOT NULL,
  `patientname` varchar(210) NOT NULL,
  `admitfrom` date NOT NULL,
  `admitupto` date NOT NULL,
  `servicetype` varchar(200) NOT NULL,
  `dayofsubmit` date NOT NULL,
  `phoneno` bigint(10) NOT NULL
) ENGINE=InnoDB;

CREATE TABLE `bedadmits` (
  `enrollno` bigint(20) NOT NULL,
  `patientname` varchar(200) NOT NULL,
  `startdate` date NOT NULL,
  `enddate` date NOT NULL,
  `bedno` bigint(20) NOT NULL,
  `servicetype` varchar(200) NOT NULL,
  `wardtype` varchar(200) NOT NULL,
  `covid19` varchar(200) NOT NULL,
  `bedstatus` varchar(100) DEFAULT NULL
) ENGINE=InnoDB;

CREATE TABLE `dailyfreetest` (
  `enrollno` bigint(20) NOT NULL,
  `patientname` varchar(200) NOT NULL,
  `loc` varchar(200) NOT NULL,
  `pincode` bigint(20) NOT NULL,
  `phone` bigint(20) NOT NULL,
  `socialdis` varchar(210) NOT NULL,
  `sanitizetime` varchar(100) NOT NULL,
  `bodytemp` varchar(200) NOT NULL,
  `chestpain` varchar(200) NOT NULL,
  `reportdate` date NOT NULL
) ENGINE=InnoDB;

CREATE TABLE `indiareport` (
  `enrollno` bigint(20) NOT NULL,
  `active` varchar(200) NOT NULL,
  `activestatus` varchar(100) NOT NULL,
  `recovered` varchar(255) NOT NULL,
  `recoveredstatus` varchar(100) NOT NULL,
  `newsymp` varchar(200) NOT NULL,
  `newsympstatus` varchar(100) NOT NULL,
  `deadcase` varchar(200) NOT NULL,
  `deathstatus` varchar(100) NOT NULL,
  `dayofupload` date NOT NULL
) ENGINE=InnoDB;

INSERT INTO `indiareport` (`enrollno`, `active`, `activestatus`, `recovered`, `recoveredstatus`, `newsymp`, `newsympstatus`, `deadcase`, `deathstatus`, `dayofupload`) VALUES
(1, '12365', 'up', '42,502,454', 'down', '12365', 'up', '521,695', 'neutral', '2022-04-10');

CREATE TABLE `isolation` (
  `enrollno` bigint(20) NOT NULL,
  `patientid` bigint(20) NOT NULL,
  `patientname` varchar(200) NOT NULL,
  `roomstatus` varchar(100) NOT NULL,
  `socialdis` varchar(100) NOT NULL,
  `handwash` varchar(100) NOT NULL,
  `oxigenlvl` varchar(100) NOT NULL,
  `bodytemp` int(11) NOT NULL,
  `dayofreport` date NOT NULL
) ENGINE=InnoDB;

CREATE TABLE `newpatientregister` (
  `enrollid` bigint(20) NOT NULL,
  `name` varchar(200) NOT NULL,
  `priphone` bigint(10) NOT NULL,
  `secphone` varchar(100) NOT NULL,
  `emailaddr` varchar(100) NOT NULL,
  `residentaddr` varchar(200) NOT NULL,
  `loc` varchar(200) NOT NULL,
  `pincode` bigint(10) NOT NULL,
  `dob` date NOT NULL,
  `age` int(11) NOT NULL,
  `profile` longblob NOT NULL
) ENGINE=InnoDB;

CREATE TABLE `statereport` (
  `enrollno` bigint(20) NOT NULL,
  `highcase` varchar(200) NOT NULL,
  `midcase` varchar(200) NOT NULL,
  `lowcase` varchar(200) NOT NULL,
  `dayofupload` date NOT NULL
) ENGINE=InnoDB;

INSERT INTO `statereport` (`enrollno`, `highcase`, `midcase`, `lowcase`, `dayofupload`) VALUES
(1, 'Chhattisgarh,Andhra Pradesh,Madhya Pradesh', 'west bengal,oddisa,sikkim', 'arunachal pradesh,kerala', '2022-04-10');

CREATE TABLE `users` (
  `enrollno` bigint(20) NOT NULL,
  `name` varchar(210) NOT NULL,
  `email` varchar(200) NOT NULL,
  `passwords` varchar(200) NOT NULL
) ENGINE=InnoDB;

CREATE TABLE `worldreport` (
  `enrollno` bigint(20) NOT NULL,
  `active` varchar(200) NOT NULL,
  `activestatus` varchar(100) NOT NULL,
  `recovered` varchar(255) NOT NULL,
  `recoveredstatus` varchar(100) NOT NULL,
  `newsymp` varchar(200) NOT NULL,
  `newsympstatus` varchar(100) NOT NULL,
  `deadcase` varchar(200) NOT NULL,
  `deathstatus` varchar(100) NOT NULL,
  `dayofupload` date NOT NULL
) ENGINE=InnoDB;

INSERT INTO `worldreport` (`enrollno`, `active`, `activestatus`, `recovered`, `recoveredstatus`, `newsymp`, `newsympstatus`, `deadcase`, `deathstatus`, `dayofupload`) VALUES
(1, '451236', 'up', '443,465,667', 'down', '451236', 'up', '6,201,853', 'neutral', '2022-04-10');
--
ALTER TABLE `admins`
  ADD PRIMARY KEY (`id`);

ALTER TABLE `admithistory`
  ADD PRIMARY KEY (`enrollno`);

ALTER TABLE `admitreq`
  ADD PRIMARY KEY (`enrollno`);

ALTER TABLE `bedadmits`
  ADD PRIMARY KEY (`enrollno`);

ALTER TABLE `dailyfreetest`
  ADD PRIMARY KEY (`enrollno`);

ALTER TABLE `indiareport`
  ADD PRIMARY KEY (`enrollno`);

ALTER TABLE `isolation`
  ADD PRIMARY KEY (`enrollno`);

ALTER TABLE `newpatientregister`
  ADD PRIMARY KEY (`enrollid`);

ALTER TABLE `statereport`
  ADD PRIMARY KEY (`enrollno`);

ALTER TABLE `users`
  ADD PRIMARY KEY (`enrollno`);

ALTER TABLE `worldreport`
  ADD PRIMARY KEY (`enrollno`);

ALTER TABLE `admins`
  MODIFY `id` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

ALTER TABLE `admithistory`
  MODIFY `enrollno` bigint(20) NOT NULL AUTO_INCREMENT;

ALTER TABLE `admitreq`
  MODIFY `enrollno` bigint(20) NOT NULL AUTO_INCREMENT;

ALTER TABLE `bedadmits`
  MODIFY `enrollno` bigint(20) NOT NULL AUTO_INCREMENT;

ALTER TABLE `dailyfreetest`
  MODIFY `enrollno` bigint(20) NOT NULL AUTO_INCREMENT;

ALTER TABLE `indiareport`
  MODIFY `enrollno` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

ALTER TABLE `isolation`
  MODIFY `enrollno` bigint(20) NOT NULL AUTO_INCREMENT;

ALTER TABLE `newpatientregister`
  MODIFY `enrollid` bigint(20) NOT NULL AUTO_INCREMENT;

ALTER TABLE `statereport`
  MODIFY `enrollno` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

ALTER TABLE `users`
  MODIFY `enrollno` bigint(20) NOT NULL AUTO_INCREMENT;

ALTER TABLE `worldreport`
  MODIFY `enrollno` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
