<!doctype html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">

    <title>covid-19 management system</title>
  </head>

  <nav class="navbar navbar-expand-lg navbar-light bg-light">
    <div class="container-fluid">
    <a class="navbar-brand" href="#">
      <img src="covid19logo.png" alt="" width="30" height="24">
    </a>
      <a class="navbar-brand" href="#">Covid-19 Management System</a>
      <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
      </button>
      <div class="collapse navbar-collapse" id="navbarSupportedContent">
        <ul class="navbar-nav me-auto mb-2 mb-lg-0">
          <li class="nav-item">
            <a class="nav-link active" aria-current="page" href="#">Home</a>
          </li>
          <li class="nav-item dropdown">
            <a class="nav-link dropdown-toggle active" href="#" id="navbarDropdown" role="button" data-bs-toggle="dropdown" aria-expanded="false">
              Patients
            </a>
            <ul class="dropdown-menu" aria-labelledby="navbarDropdown">
              <li><a class="dropdown-item myitems" href="userlogin.html">login</a></li>
              <li><a class="dropdown-item myitems" href="userlogout.php">quick logout</a></li>
           
              <li><a class="dropdown-item myitems" href="dailyfreetest.html">Daily free test action</a></li>
              <li><a class="dropdown-item myitems" href="admitrequest.html">Admit request</a></li>
             
              <li><hr class="dropdown-divider"></li>
              <li><a class="dropdown-item myitems" href="isolation.html">Daily isolation test</a></li>

              <style>
                .myitems:hover {
      background-color: blue;
      color:white;
    }
            </style>
         
            </ul>
          </li>

          <li class="nav-item">
            <a class="nav-link active" aria-current="page" href="admin_pannel/admin.html">Admin Pannel</a>
          </li>
        

        </ul>
         </div>
    </div>
  </nav>
  


  <body>
  
<br>
<br>
<br>


    <!-- covid 19 resport overview -->

    <div class="container">
        <div class="row">
        <br>
    
    <p class="text-center" style="font-size:30px;"><b>
        India's all over covid report
    </b></p>
    <br>
          <!-- india covid report -->
          <div class="row">
              <div class="col-3">
                  <div class="row">
                      <div class="col-6">
                          <font style="font-size: 20px;" style="color: rgb(44, 44, 4);">
                        Active Cases
                        </font>
                        <br>
    <?php
    include 'covidreportDBconfig.php';
    
    $sql12 = "SELECT * FROM indiareport";
    $q1 =  mysqli_query($covidrep,$sql12);
    $row = mysqli_fetch_assoc($q1);
    
    $activeCase = $row['active'];
    $activestatus = $row['activestatus'];
    $recoverCase = $row['recovered'];
    $recoverstatus = $row['recoveredstatus'];
    $newCase = $row['newsymp'];
    $newstatus = $row['newsympstatus'];
    $deadCase = $row['deadcase'];
    $deadstatus = $row['deathstatus'];
    $dayofupload = $row['dayofupload'];
    
    echo $activeCase;
    
    ?>
                      </div>
                      <div class="col-6">
                   <font style="font-size: 20px;">
                        status
                   </font>  
                   <br>
                   <?php
                   echo $activestatus;
                   ?>
                 </div>
                  </div>
    
              </div>
              <div class="col-3">
    <div class="row">
                      <div class="col-6">
                          <font style="font-size: 20px;color: green;">
                        Recovered Cases
                        </font>
                        <br>
    <?php
    echo $recoverCase;
    ?>
                      </div>
                      <div class="col-6">
                        <font style="font-size: 20px;">
                            status
                       </font>  
                       <br>
                       <?php
    echo $recoverstatus;
                       ?>
                            </div>
                  </div>
                  
              </div>
              <div class="col-3">
                <div class="row">
                    <div class="col-6">
                        <font style="color: blue;font-size: 20px;" >
                      New Cases
                      </font>
                      <br>
                      <?php
                      echo $newCase;
                      ?>
                      <br>
    
                    </div>
                    <div class="col-6">
                        <font style="font-size: 20px;">
                            status
                       </font>  
                       <br>
                       <?php
                       echo $newstatus;
                       ?>
                             </div>
                </div>
                
              </div>
              <div class="col-3">
                <div class="row">
                    <div class="col-8">
                        <font style="color: red;font-size: 20px;">
                      Death Cases
                      </font>
                      <br>
    <?php
    echo $deadCase;
    ?>
                    </div>
                    <div class="col-4">
                        <font style="font-size: 20px;">
                            status
                       </font>  
                       <br>
                       <?php
                            echo $deadstatus;
                       ?>
                        </div>
                </div>
    
            </div>
          </div>
    
    
                <br>
                <br>
    
    <p class="text-center" style="font-size: 30px;"><b>
        India state's covid report
    </b></p>
                <br>
                <br>
    
                      <!-- state covid report -->
          <div class="row">
            <div class="col-4">
                <div class="row">
    
                <?php
    include 'covidreportDBconfig.php';
    $sql14 = "SELECT * FROM statereport";
    $q3 =  mysqli_query($covidrep,$sql14);
    
    $row = mysqli_fetch_assoc($q3);
    
    $highcase = $row['highcase'];
    $midcase = $row['midcase'];
    $lowcase = $row['lowcase'];
    $dayofupload = $row['dayofupload'];
    
    
                ?>
                    <div class="col">
                        <font style="color: rgb(44, 44, 4);font-size: 20px;">
                      High Cases
                      </font>
                      <br>
                      <table>
                          <td>
    <?php echo $highcase; ?>
                          </td>
                      </table>
                    </div>
                </div>
    
            </div>
            <div class="col-4">
                <div class="row">
                    <div class="col">
                        <font style="color: rgb(44, 44, 4);font-size: 20px;">
                      Middle Cases
                      </font>
                      <br>
                      <table>
                          <td>
                          <?php echo $midcase; ?>
                          </td>
                      </table>
                    </div>
                </div>
    
                
            </div>
            <div class="col-4">
                <div class="row">
                    <div class="col">
                        <font style="color: rgb(44, 44, 4);font-size: 20px;">
                      Lower Cases
                      </font>
                      <br>
                      <table>
                          <td>
                          <?php echo $lowcase; ?>
                          </td>
                      </table>
                    </div>
                </div>
    
            </div>
           
        </div>
    
    <br>
    <br>
    <br>
    
    <p class="text-center" style="font-size: 30px;"><b>
        World's covid report
    </b></p>
    
    <br>
    
    <br>
    
           <!-- world covid report -->
           <div class="row">
                    <div class="col-3">
                        <div class="row">
                            <div class="col-6">
                                <font style="color: rgb(44, 44, 4);font-size: 20px;">
                              Active Cases
                              </font>
                              <br>
                              <?php
                                include 'covidreportDBconfig.php';
    
                                $sql13 = "SELECT * FROM worldreport";
    $q2 =  mysqli_query($covidrep,$sql13);
    $row = mysqli_fetch_assoc($q2);
    
    $activeCase2 = $row['active'];
    $activestatus2 = $row['activestatus'];
    $recoverCase2 = $row['recovered'];
    $recoverstatus2 = $row['recoveredstatus'];
    $newCase2 = $row['newsymp'];
    $newstatus2 = $row['newsympstatus'];
    $deadCase2 = $row['deadcase'];
    $deadstatus2 = $row['deathstatus'];
    $dayofupload2 = $row['dayofupload'];
    
    echo $activeCase2;
    
                              ?>
                              <br>
          
                            </div>
                            <div class="col-6">
                                <font style="font-size: 20px;">
                                    status
                               </font>  
                               <br>
                               <?php
    echo $activestatus2;
                               ?>
                                    </div>
                        </div>
          
                    </div>
                    <div class="col-3">
          <div class="row">
                            <div class="col-6">
                                <font style="color: green;font-size: 20px;">
                                    Recovered Cases
                              </font>
                              <br>
          <?php echo $recoverCase2; ?>
                            </div>
                            <div class="col-6">
                                <font style="font-size: 20px;">
                                    status
                               </font>  
                               <br>
                               <?php  echo $recoverstatus2; ?>
                                  </div>
                        </div>
                        
                    </div>
                    <div class="col-3">
                      <div class="row">
                          <div class="col-6">
                              <font style="color: blue;font-size: 20px;">
                            New Cases
                            </font>
                            <br>
          <?php  echo $newCase2;
          ?>
                          </div>
                          <div class="col-6">
                            <font style="font-size: 20px;">
                                status
                           </font>  
                           <br>
                           <?php echo $newstatus2; ?>
                               </div>
                      </div>
                      
                    </div>
                    <div class="col-3">
                      <div class="row">
                          <div class="col-6">
                              <font style="color: red;font-size: 20px;">
                            Death Cases
                            </font>
                            <br>
          <?php echo $deadCase2; ?>
                          </div>
                          <div class="col-6">
                            <font style="font-size: 20px;">
                                status
                           </font> 
                           <br>
                           <?php echo $deadstatus2; ?> 
                           </div>
                      </div>
          
                  </div>
                </div>
         
         
        </div>
      </div>

      




    <!-- Optional JavaScript; choose one of the two! -->

    <!-- Option 1: Bootstrap Bundle with Popper -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-MrcW6ZMFYlzcLA8Nl+NtUVF0sA7MsXsP1UyJoMp4YLEuNSfAP+JcXn/tWtIaxVXM" crossorigin="anonymous"></script>

    <!-- Option 2: Separate Popper and Bootstrap JS -->
    <!--
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.9.2/dist/umd/popper.min.js" integrity="sha384-IQsoLXl5PILFhosVNubq5LC7Qb9DXgDA9i+tQ8Zj3iwWAwPtgFTxbJ8NT4GN1R8p" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.min.js" integrity="sha384-cVKIPhGWiC2Al4u+LWgxfKTRIcfu0JTxR+EQDz/bgldoEyl4H0zUF0QKbrJ0EcQF" crossorigin="anonymous"></script>
    -->
  </body>
</html>
