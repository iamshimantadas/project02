
<html>
    <body>
        <font style="font-size:20px;">
                plz wait for 5 seconds ....
        </font>
        <br>
        <br>

    <script>
         setTimeout(function(){
            window.location.href = 'index.php';
         }, 5000);
      </script>


    </body>
</html>


<?php

include 'connection.php';

session_start();

if ($_SESSION["userlogin"]) {
  # code...
} else {
  echo "plz do the login";
  header("Location: userlogin.html");
}


$name=    $_POST['name'];
 $loc=   $_POST['loc'];
 $pincode=   $_POST['pincode'];
 $socaildis=   $_POST['socialdis'];
 $handwash=   $_POST['handwash'];
 $bodytemp=   $_POST['bodytemp'];
 $chestpain=   $_POST['chestpain'];
  $phone=  $_POST['phone'];
  $reportdate = date("Y/m/d") ;


  echo "Your name is :".$name;
  echo "<br>";
  echo "Your localtion :".$loc;
  echo "<br>";
  echo "Your pincode is :".$pincode;
  echo "<br>";
  echo "social distance status :".$socaildis;
  echo "<br>";
  echo "handwash times :".$handwash;
  echo "<br>";
  echo "Your body temparature :".$bodytemp;
  echo "<br>";
  echo "Your chest pian status :".$chestpain;
  echo "<br>";
  echo "Your phone number :".$phone;
  echo "<br>";



    $sql5="INSERT INTO `dailyfreetest` (`enrollno`, `patientname`, `loc`, `pincode`, `phone`, `socialdis`, `sanitizetime`, `bodytemp`, `chestpain`, `reportdate`) VALUES (NULL, '$name', '$loc', '$pincode', '$phone', '$socaildis', '$handwash', '$bodytemp', '$chestpain', '$reportdate')";
    $query =  mysqli_query($conn,$sql5);

    if ($query) {
        echo "your test report saved into our database , we will respond you soon :) ";
    } else {
       echo "plz try again :( ";
    }

?>

