<html>
    <body>
        <font style="font-size:20px;">
                plz wait for 5 seconds ....
        </font>
        <br>
        <br>

    <script>
         setTimeout(function(){
            window.location.href = 'index.php';
         }, 5000);
      </script>


    </body>
</html>


<?php
include 'connection.php';

 $name =    $_POST['name'];
  $servicereq =  $_POST['servicereq'];
 $admitfrom =   $_POST['admitfrom'];
 $admitupto =   $_POST['admitupto'];
 $phoneno =   $_POST['phoneno'];
$dayofsubmit =     date("Y/m/d");

    $sql2="INSERT INTO `admitreq` (`enrollno`, `patientname`, `admitfrom`, `admitupto`, `servicetype`, `dayofsubmit`,`phoneno`) VALUES (NULL, '$name', '$admitfrom', '$admitupto', '$servicereq', '$dayofsubmit','$phoneno')";
    $query=  mysqli_query($conn,$sql2);

    if ($query) {
        echo "patient admit request successfully saved into our database :) ";
    } else {
        echo "plz try again :( ";
    }

?>
