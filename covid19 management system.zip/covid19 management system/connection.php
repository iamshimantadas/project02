<?php
$host="localhost";
$user="root";
$pass="";
$db="healthcare";

$conn = mysqli_connect($host,$user,$pass,$db);

if ($conn) {
  //echo "database connected";
} else {
  //  echo "database not connected";
}

error_reporting(0);

?>