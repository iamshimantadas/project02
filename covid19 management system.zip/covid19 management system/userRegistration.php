<html>
    <body>
        <font style="font-size:20px;">
                plz wait for 5 seconds ....
        </font>
        <br>
        <br>

    <script>
         setTimeout(function(){
            window.location.href = 'index.php';
         }, 5000);
      </script>


    </body>
</html>


<?php
include 'connection.php';

$name =     $_POST['name'];
 $email =    $_POST['email'];
  $pass=   $_POST['password'];

echo "<br>";
echo "Your full name : ".$name;
echo "<br>";
echo "Your userid/email : ".$email;
echo "<br>";
echo "Your account password is : ".$pass;
echo "<br>";



  $sql="INSERT INTO `users` (`enrollno`, `name`, `email`, `passwords`) VALUES (NULL, '$name', '$email', '$pass')";

  $query=  mysqli_query($conn,$sql);


  if ($query) {
     echo "user registration got successful .. ";
  } else {
      echo "plz try again :( ";
  }


?>

