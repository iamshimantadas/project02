<html lang="en">
    <head>
      <!-- Required meta tags -->
      <meta charset="utf-8">
      <meta name="viewport" content="width=device-width, initial-scale=1">
  
      <!-- Bootstrap CSS -->
      <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
  
      <title>admin control pannel</title>
    </head>
    <body>
  
    <br>
  <?php
  include 'connection.php';
  
  $_SESSION["adminloggedin"] = "validlogin";
  
  
  
  ?>
  <br>
  <br>
   
<div class="container">
<div class="row">
        <div class="col-4">
            <font style="font-size:20px;">
          <b>
              upload new covid report of all over India
          </b>
          </font>
          <br>
          <br>
          <a href="indiaReport.html">
          <button type="button" class="btn btn-outline-dark">update now</button>
          </a>
        </div>
        <div class="col-4">
        <font style="font-size:20px;">
          <b>
              upload new covid report of all states of India
          </b>
          </font>
          <br>
          <br>
          <a href="stateReport.html">
          <button type="button" class="btn btn-outline-dark">update now</button>
          </a>
        </div>
        <div class="col-4">
        <font style="font-size:20px;">
          <b>
              upload new covid report of all over world
          </b>
          </font>
          <br>
          <br>
          <a href="worldReport.html">
          <button type="button" class="btn btn-outline-dark">update now</button>
          </a>
        </div>
    </div>
  <br>
  <br>
  
  <div class="row">
  <div class="col-2">
  <img src="bedallot.png" class="img-thumbnail" alt="..." style="max-height:100px;max-width:100px;">
          <br>
          <a href="bedAdmits.html">
          <button type="button" class="btn btn-primary">New patint admits & bed allot </button>
          </a>
     
  </div>
  <div class="col-2">
  <img src="freebed.jpg" class="img-thumbnail" alt="..." style="max-height:100px;max-width:100px;">
          <br>
          <a href="freeBedAllot.html">
          <button type="button" class="btn btn-primary">Free bed allot</button>
          </a>
     
  
  </div>
  <div class="col-2">
  <img src="admitreq.jpg" class="img-thumbnail" alt="..." style="max-height:100px;max-width:100px;">
          <br>
          <a href="viewallAdmitsreq.php">
          <button type="button" class="btn btn-primary">view all admit requests</button>
          </a>
  
  </div>
  <div class="col-3">
    <a href="allBedStatus.php">
    <button type="button" class="btn btn-outline-primary">All bed status</button>
    </a>
    <br>
    <br>
    <a href="bedNoStatus.html">
    <button type="button" class="btn btn-outline-primary">Bed No status</button>
    </a>
   
  </div>
  <div class="col-3">
  <a href="bookedBedLists.php">
    <button type="button" class="btn btn-outline-primary">Booked bed lists</button>
    </a>
   <br> <br>
   <a href="freeBedLists.php">
    <button type="button" class="btn btn-outline-primary">Free bed lists</button>
    </a>
   
  </div>
  </div>
  
  <br><br>
  
  <div class="row">
    <div class="col-4">
    <img src="newpatientregistration.png" class="img-thumbnail" alt="..." style="max-height:100px;max-width:100px;">
  <br>
    <a href="newpatientRegistration.html">
    <button type="button" class="btn btn-outline-primary">New Patients's registration</button>
    </a>
    
    </div>
    <div class="col-4">
    <img src="osrtuser.jpeg" class="img-thumbnail" alt="..." style="max-height:100px;max-width:100px;">
  <br>
    <a href="findIDbyNamePhone.html">
    <button type="button" class="btn btn-outline-primary">Find patient's info by name & phone</button>
    </a>
   
    </div>
    <div class="col-4">
    <img src="find.png" class="img-thumbnail" alt="..." style="max-height:100px;max-width:100px;">
  <br>
    <a href="sortById.html">
    <button type="button" class="btn btn-outline-primary">Search patient's using ID</button>
    </a>
   
    </div>
  </div>
  <br>
  <br>

  <div class="row">
    <div class="col-5" style="border: 2px solid red;">
      <font style="font-size:15px;">
        <b>
        Daily free test reports ...
        </b>  
         </font>
         <br>
         <a href="dailyFreeTestRecordView.php">
               <button type="button" style="background-color:blue;color:white;">All free test records</button>
               </a>
          <br> <br>
          <a href="sortbydate.html">
               <button type="button" style="background-color:blue;color:white;">sort by date</button>
               </a>
          
           
    </div>
    <div class="col-2"></div>
    <div class="col-5" style="border: 2px solid red;">
      <font style="font-size:15px;">
        <b>
        Isolation test's records ... 
        </b> 
         </font>
         <br>
         <div class="row">
           <div class="col-6">
           <a href="sortBydateIsolation.html">
               <button type="button" style="background-color:blue;color:white;position:left;">Sort by date</button>
               </a>
         </div>
           <div class="col-6">
           <a href="sortbyIdIsolation.html">
               <button type="button" style="background-color:blue;color:white;position:right;">sort by patinet's id</button>
               </a>
          </div>
         </div>
          <br>
          <div class="row">
            <div class="col-6">
            <a href="sortByNameIsolation.html">
               <button type="button" style="background-color:blue;color:white;">sort by patient's name</button>
               </a>
          
            </div>
            <div class="col-6">
            <a href="viewAllIsolationRecords.php">
               <button type="button" style="background-color:blue;color:white;">view all isolation reports</button>
               </a>
         
            </div>
          </div>
     

    </div>
  </div>
</div>


<br>
<br>

<div class="row">
  <div class="col-4"></div>
  <div class="col-4">
  <a href="logout.php">
    <button type="button" class="btn btn-outline-danger">Logout</button>
    </a> 
</div>
  <div class="col-4"></div>
</div>
      <!-- Optional JavaScript; choose one of the two! -->
  
      <!-- Option 1: Bootstrap Bundle with Popper -->
      <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-MrcW6ZMFYlzcLA8Nl+NtUVF0sA7MsXsP1UyJoMp4YLEuNSfAP+JcXn/tWtIaxVXM" crossorigin="anonymous"></script>
  
      <!-- Option 2: Separate Popper and Bootstrap JS -->
      <!--
      <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.9.2/dist/umd/popper.min.js" integrity="sha384-IQsoLXl5PILFhosVNubq5LC7Qb9DXgDA9i+tQ8Zj3iwWAwPtgFTxbJ8NT4GN1R8p" crossorigin="anonymous"></script>
      <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.min.js" integrity="sha384-cVKIPhGWiC2Al4u+LWgxfKTRIcfu0JTxR+EQDz/bgldoEyl4H0zUF0QKbrJ0EcQF" crossorigin="anonymous"></script>
      -->
    </body>
  </html>
