<?php
session_start();
// remove all session variables
session_unset();

// destroy the session
session_destroy(); 

echo "you louout done ";


?>

<html>
    <body>
        <font style="font-size:20px;">
You logout done successfully .... :) 
<br>
plz come back again .... 
        </font>
        <br>
        <br>
         
    <font style="font-size:20px;">
                plz wait for 5 seconds .... 
        </font>
        <br>
        <br>

    <script>
         setTimeout(function(){
            window.location.href = 'admincontrolpannel.php';
         }, 5000);
      </script>
  
    </body>
</html>