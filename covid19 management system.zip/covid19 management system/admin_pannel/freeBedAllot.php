<html>
<body>
<?php 
$bedno= $_POST['bedno'];
include 'connection.php';



$mysqli = $conn;


$freebedquery = "UPDATE bedadmits SET `patientname` = 'NOANY', `startdate` = '2022-01-01', `enddate` = '2022-01-01',servicetype='none' ,wardtype='none',covid19='none',bedstatus = 'FREE' WHERE `bedno` = '$bedno'";
$query = $freebedquery;
$free =  mysqli_query($conn,$query);
if ($free) {
    echo "<br>";
    echo "free bed successfully alloted .... ";
}

$afterrecord = "SELECT * FROM bedadmits WHERE bedno='$bedno'";


echo '<table border="2px" cellspacing="2" cellpadding="2"> 
      <tr> 
          <td> <font face="Arial">Enroll No</font> </td> 
          <td> <font face="Arial">Patient Name</font> </td> 
          <td> <font face="Arial">Start Date</font> </td> 
          <td> <font face="Arial">End Date</font> </td> 
          <td> <font face="Arial">Bed No Number</font> </td> 
         <td> <font face="Arial">Service Type</font> </td> 
          <td> <font face="Arial">Ward Type/day</font> </td> 
          <td> <font face="Arial">Covid-19 Status</font> </td> 
          <td> <font face="Arial">Bed Status</font> </td> 
        
          </tr>';

if ($result = $mysqli->query($afterrecord)) {
    while ($row = $result->fetch_assoc()) {
        $field1name = $row["enrollno"];
        $field2name = $row["patientname"];
        $field3name = $row["startdate"];
        $field4name = $row["enddate"];
        $field5name = $row["bedno"];
        $field6name = $row["servicetype"];
        $field7name = $row["wardtype"];
        $field8name = $row["covid19"];
        $field9name = $row["bedstatus"];
        

    echo '<tr> 
                  <td>'.$field1name.'</td> 
                  <td>'.$field2name.'</td> 
                  <td>'.$field3name.'</td> 
                  <td>'.$field4name.'</td> 
                  <td>'.$field5name.'</td>
                  <td>'.$field6name.'</td>
                  <td>'.$field7name.'</td>
                  <td>'.$field8name.'</td>
                  <td>'.$field9name.'</td>
                  </tr>';
    }
    $result->free();

} 
?>
</body>

<br>
<br>
        <font style="font-size:20px;">
                plz wait for 5 seconds .... 
        </font>
        <br>
        <br>

    <script>
         setTimeout(function(){
            window.location.href = 'admincontrolpannel.php';
         }, 5000);
      </script>
     

</html>