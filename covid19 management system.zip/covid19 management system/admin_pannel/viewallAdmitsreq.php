<html>
<body>
<?php 

include 'connection.php';

$mysqli = $conn;

$query = "SELECT * FROM admitreq";


echo '<table border="2px" cellspacing="2" cellpadding="2"> 
      <tr> 
          <td> <font face="Arial">Enroll No</font> </td> 
          <td> <font face="Arial">Patient Full Name</font> </td> 
          <td> <font face="Arial">Admit From</font> </td> 
          <td> <font face="Arial">Admit Upto</font> </td> 
          <td> <font face="Arial">Service Tye</font> </td> 
          <td> <font face="Arial">Contact</font> </td>
          <td> <font face="Arial">Day of request</font> </td> 
       
          </tr>';

if ($result = $mysqli->query($query)) {
    while ($row = $result->fetch_assoc()) {
        $field1name = $row["enrollno"];
        $field2name = $row["patientname"];
        $field3name = $row["admitfrom"];
        $field4name = $row["admitupto"];
        $field5name = $row["servicetype"];
        $field6name = $row["phoneno"];
        $field7name = $row["dayofsubmit"];
      


         


        echo '<tr> 
                  <td>'.$field1name.'</td> 
                  <td>'.$field2name.'</td> 
                  <td>'.$field3name.'</td> 
                  <td>'.$field4name.'</td> 
                  <td>'.$field5name.'</td>
                  <td>'.$field6name.'</td>
                  <td>'.$field7name.'</td>
                  </tr>';
    }
    $result->free();

} 
?>
</body>
</html>