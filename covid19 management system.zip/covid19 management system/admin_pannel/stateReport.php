<?php

include 'connection.php';

$high=    $_POST['highcases'];
$mid=    $_POST['midcases'];
 $low=   $_POST['lowcases'];
 $dayofsubmit =     date("Y/m/d");

 $trun1 = "TRUNCATE TABLE statereport";
 $destroyTable = mysqli_query($conn,$trun1);

 if ($destroyTable) {

   echo "<br>";
    echo "old report deleted successfully ... ";
 }

$sql8="INSERT INTO `statereport` (`enrollno`, `highcase`, `midcase`, `lowcase`, `dayofupload`) VALUES (NULL, '$high', '$mid', '$low', '$dayofsubmit')";
$query =  mysqli_query($conn,$sql8);

if ($query) {
   echo "<br>";
   echo "state report uploaded :) ";
} else {

   echo "plz try again :(  ";
}


?>

<html>
   <body>
      
   <font style="font-size:20px;">
                plz wait for 5 seconds .... 
        </font>
        <br>
        <br>

    <script>
         setTimeout(function(){
            window.location.href = 'admincontrolpannel.php';
         }, 5000);
      </script>
  
  
   </body>
</html>