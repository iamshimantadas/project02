<?php

include 'connection.php';



$activeCase=    $_POST['activecase'];
$activeStatus=   $_POST['activestatus'];
    $recoverCase=   $_POST['reovercase'];
    $recoverStatus=   $_POST['reoverstatus'];
    $newCase=  $_POST['newcase'];
    $newcasesStatus=    $_POST['newstatus'];
    $deathcase=  $_POST['deathcase'];
    $deathstatus=    $_POST['deathstatus'];
   
    $dayofsubmit =     date("Y/m/d");

echo "<br>";
echo "active cases ".$activeCase;
echo "<br>";
echo "active case's status".$activeStatus;
echo "<br>";
echo "recover cases ".$recoverCase;
echo "<br>";
echo "recover case's status ".$recoverStatus;
echo "<br>";
echo "new cases ".$newCase;
echo "<br>";
echo "new case's status".$newcasesStatus;
echo "<br>";
echo "death cases ".$deathcase;
echo "<br>";
echo "death case's status".$deathstatus;
echo "<br>";
echo "day of submit this report ".$dayofsubmit;

$trun2 = "TRUNCATE TABLE indiareport";
 $destroyTable2 = mysqli_query($conn,$trun2);

 if ($destroyTable2) {

    echo "<br>";
    echo "old report deleted successfully ... ";
 }

if ($conn) {
    echo "connection got";
}

$sql7="INSERT INTO `indiareport` (`enrollno`, `active`, `activestatus`, `recovered`, `recoveredstatus`, `newsymp`, `newsympstatus`, `deadcase`, `deathstatus`, `dayofupload`) VALUES (NULL, '$newCase', '$newcasesStatus', '$recoverCase', '$recoverStatus', '$newCase', '$newcasesStatus', '$deathcase', '$deathstatus', '$dayofsubmit')";
$query = mysqli_query($conn,$sql7);

if ($query) {
    echo "<br>";
    echo "india covid new report updates successfully ... ";
} else {
    echo "plz try again :( ";
}

?>


<html>
    <body>
        
    <font style="font-size:20px;">
                plz wait for 5 seconds .... 
        </font>
        <br>
        <br>

    <script>
         setTimeout(function(){
            window.location.href = 'admincontrolpannel.php';
         }, 5000);
      </script>
  
    </body>
</html>