<html>
<body>
<?php 

include 'connection.php';

$mysqli = $conn;

$startdate = $_POST['startdate'];
$enddate = $_POST['enddate'];

$query = "SELECT * FROM isolation WHERE dayofreport BETWEEN '$startdate' AND '$enddate'";


echo '<table border="2px" cellspacing="2" cellpadding="2"> 
      <tr> 
      <td> <font face="Arial">Enroll No</font> </td> 
      <td> <font face="Arial">Patient ID</font> </td> 
      <td> <font face="Arial">Patient Name</font> </td> 
      <td> <font face="Arial">Room Status</font> </td> 
      <td> <font face="Arial">Social Distance</font> </td> 
      <td> <font face="Arial">Handwash</font> </td> 
      <td> <font face="Arial">Oxigen Level 1</font> </td> 
      <td> <font face="Arial">Body Temp</font> </td> 
      <td> <font face="Arial">Day of report</font> </td> 
     </tr>';

if ($result = $mysqli->query($query)) {
    while ($row = $result->fetch_assoc()) {
        $field1name = $row["enrollno"];
        $field2name = $row["patientid"];
        $field3name = $row["patientname"];
        $field4name = $row["roomstatus"];
        $field5name = $row["socialdis"];
        $field6name = $row["handwash"];
        $field7name = $row["oxigenlvl"];
        $field8name = $row["bodytemp"];
        $field9name = $row["dayofreport"];
      


         


        echo '<tr> 
        <td>'.$field1name.'</td> 
        <td>'.$field2name.'</td> 
        <td>'.$field3name.'</td> 
        <td>'.$field4name.'</td> 
        <td>'.$field5name.'</td>
        <td>'.$field6name.'</td>
        <td>'.$field7name.'</td>
        <td>'.$field8name.'</td>
        <td>'.$field9name.'</td>
       </tr>';
    }
    $result->free();


} 
?>
</body>

<br>
<br>


<font style="font-size:20px;">
                plz wait for 5 seconds .... 
        </font>
        <br>
        <br>

    <script>
         setTimeout(function(){
            window.location.href = 'admincontrolpannel.php';
         }, 5000);
      </script>
     


</html>