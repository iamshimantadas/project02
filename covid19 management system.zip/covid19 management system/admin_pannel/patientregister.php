<html>
    <body>
    <font style="font-size:20px;">
                plz wait for 5 seconds .... 
        </font>
        <br>
        <br>

    <script>
         setTimeout(function(){
            window.location.href = 'admincontrolpannel.php';
         }, 5000);
      </script>
  
    </body>
</html>


<?php

$host="localhost";
$user="root";
$pass="";
$db="healthcare";

$conn = mysqli_connect($host,$user,$pass,$db);


error_reporting(0);


 $fname=       $_POST['fname'];
 $mnane =       $_POST['mname'];
  $lname =       $_POST['lname'];
  $prinumber =      $_POST['prinumber'];
  $secnumber =      $_POST['secnumber'];
  $email=      $_POST['email'];
   $addr=     $_POST['addr'];
   $loc=     $_POST['loc'];
   $pincode=     $_POST['pincode'];
   $dob=     $_POST['dob'];
   $age=     $_POST['age'];
   $imagefile = addslashes(file_get_contents($_FILES['image']['tmp_name']));
    

     $fullname = $fname." ".$mnane." ".$lname;

     echo "<br>";
     echo "patient fullname ".$fullname;
     echo "<br>";
     echo "patient primary phone number ".$prinumber;
     echo "<br>";
     echo "secondary phone number  ".$secnumber;
     echo "<br>";
     echo "patient's email is ".$email;
     echo "<br>";
     echo "patient's address is ".$addr;
     echo "<br>";
     echo "location is ".$loc;
     echo "<br>";
     echo "pincode is ".$pincode;
     echo "<br>";
     echo "date of birth is ".$dob;
     echo "<br>";
     echo "Patient's age is ".$age;
     echo "<br>";
    
$sql="INSERT INTO `newpatientregister` (`enrollid`, `name`, `priphone`, `secphone`, `emailaddr`, `residentaddr`, `loc`, `pincode`, `dob`, `age`, `profile`) VALUES (NULL, '$fullname', '$prinumber', '$secnumber', '$email', '$addr', '$loc', '$pincode', '$dob', '$age', '$imagefile')";
     $query =  mysqli_query($conn,$sql);

if ($query) {

    echo "<br>";
    echo "<br>";
   echo "patient has been successfully registerred :) ";
} else {
    echo "plz try again :( ";
}

$finpatineid ="SELECT * FROM newpatientregister WHERE priphone='$prinumber'";
$query2 =  mysqli_query($conn,$finpatineid);
$row = mysqli_fetch_assoc($query2);
$patientid = $row['enrollid'];

echo "<br>";
echo "<br>";
echo "patinet's id ->  ".$patientid;
echo "<br>";
echo "<br>";
echo "plz note down patient's id number carefully , it will require for furthur operation";




?>


