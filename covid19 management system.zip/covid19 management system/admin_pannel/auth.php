<?php
include 'connection.php';

 $username =    $_POST['adminid'];
 $pass =   $_POST['password'];

    $authsql="SELECT * FROM admins WHERE username='$username' AND passwords='$pass'";
$query =  mysqli_query($conn,$authsql);


$row = mysqli_fetch_assoc($query);

        if ($row['username']) {
            echo "your login successful .... ";
           
            header("Location:admincontrolpannel.php");

        } else {
            echo "invalid login , plz enter correct userid and password :( ";
        }
        
?>