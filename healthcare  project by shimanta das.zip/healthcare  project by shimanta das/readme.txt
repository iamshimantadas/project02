﻿
/*
readme for open-source healthcare system ...... 

* Important files configuration - 

1. in every you will find a connection.php file , now there have 4 fields - host,user,pass,db ; now for local machine 
if you use windows or either linux or mac , 
the pass(denotes password of mysql/phpmyadmin) -> will be changed according to system configuration.
2. you will find 2nd file , covidreportDBconfig.php -> this file , configuration also need to done carefully ... ok :) 
3. admin pannel authentification - 
userid - admin
password - admin123

* setup & configure to our system - 
-> windows -  put all the files under C:\xampp\htdocs (xampp users only)
xampp : https://www.apachefriends.org/index.html
-> linux - /var/www/html -> put all the files .
or, xampp -> /opt/lampp/htdocs -> put all the files  [for xampp' users]
-> mac - find from youtube that how we can configure into mac as php coding files.

* for server-production deployment - 

paste all the file into /public_html directory and refresh the location in browser :) 


this code is lisenced under - GPL and GNU open-source lisence.

*/
