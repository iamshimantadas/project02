-- phpMyAdmin SQL Dump
-- version 4.9.5deb2
-- https://www.phpmyadmin.net/
--
-- Host: localhost:3306
-- Generation Time: Mar 29, 2022 at 08:11 PM
-- Server version: 8.0.28-0ubuntu0.20.04.3
-- PHP Version: 7.4.3

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `healthcare`
--

-- --------------------------------------------------------

--
-- Table structure for table `admins`
--

CREATE TABLE `admins` (
  `id` bigint NOT NULL,
  `username` varchar(200) NOT NULL,
  `passwords` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `admins`
--

INSERT INTO `admins` (`id`, `username`, `passwords`) VALUES
(1, 'admin', 'admin123');

-- --------------------------------------------------------

--
-- Table structure for table `admithistory`
--

CREATE TABLE `admithistory` (
  `enrollno` bigint NOT NULL,
  `patientname` varchar(200) NOT NULL,
  `startdate` date NOT NULL,
  `enddate` date NOT NULL,
  `bedno` bigint NOT NULL,
  `servicetype` varchar(200) NOT NULL,
  `wardtype` varchar(200) NOT NULL,
  `covid19` varchar(200) NOT NULL,
  `bedstatus` varchar(100) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- --------------------------------------------------------

--
-- Table structure for table `admitreq`
--

CREATE TABLE `admitreq` (
  `enrollno` bigint NOT NULL,
  `patientname` varchar(210) NOT NULL,
  `admitfrom` date NOT NULL,
  `admitupto` date NOT NULL,
  `servicetype` varchar(200) NOT NULL,
  `dayofsubmit` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- --------------------------------------------------------

--
-- Table structure for table `bedadmits`
--

CREATE TABLE `bedadmits` (
  `enrollno` bigint NOT NULL,
  `patientname` varchar(200) NOT NULL,
  `startdate` date NOT NULL,
  `enddate` date NOT NULL,
  `bedno` bigint NOT NULL,
  `servicetype` varchar(200) NOT NULL,
  `wardtype` varchar(200) NOT NULL,
  `covid19` varchar(200) NOT NULL,
  `bedstatus` varchar(100) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- --------------------------------------------------------

--
-- Table structure for table `dailyfreetest`
--

CREATE TABLE `dailyfreetest` (
  `enrollno` bigint NOT NULL,
  `patientname` varchar(200) NOT NULL,
  `loc` varchar(200) NOT NULL,
  `pincode` bigint NOT NULL,
  `phone` bigint NOT NULL,
  `socialdis` varchar(210) NOT NULL,
  `sanitizetime` varchar(100) NOT NULL,
  `bodytemp` varchar(200) NOT NULL,
  `chestpain` varchar(200) NOT NULL,
  `reportdate` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- --------------------------------------------------------

--
-- Table structure for table `indiareport`
--

CREATE TABLE `indiareport` (
  `enrollno` bigint NOT NULL,
  `active` varchar(200) NOT NULL,
  `activestatus` varchar(100) NOT NULL,
  `recovered` varchar(255) NOT NULL,
  `recoveredstatus` varchar(100) NOT NULL,
  `newsymp` varchar(200) NOT NULL,
  `newsympstatus` varchar(100) NOT NULL,
  `deadcase` varchar(200) NOT NULL,
  `deathstatus` varchar(100) NOT NULL,
  `dayofupload` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- --------------------------------------------------------

--
-- Table structure for table `isolation`
--

CREATE TABLE `isolation` (
  `enrollno` bigint NOT NULL,
  `patientid` bigint NOT NULL,
  `patientname` varchar(200) NOT NULL,
  `roomstatus` varchar(100) NOT NULL,
  `socialdis` varchar(100) NOT NULL,
  `handwash` varchar(100) NOT NULL,
  `oxigenlvl` varchar(100) NOT NULL,
  `bodytemp` int NOT NULL,
  `dayofreport` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- --------------------------------------------------------

--
-- Table structure for table `patientregister`
--

CREATE TABLE `patientregister` (
  `patientid` bigint NOT NULL,
  `patientname` varchar(200) NOT NULL,
  `phone1` bigint NOT NULL,
  `phone2` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `addr` varchar(200) NOT NULL,
  `loc` varchar(200) NOT NULL,
  `pincode` bigint NOT NULL,
  `dob` date NOT NULL,
  `age` int NOT NULL,
  `image` longblob NOT NULL,
  `oldsymp` varchar(220) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- --------------------------------------------------------

--
-- Table structure for table `statereport`
--

CREATE TABLE `statereport` (
  `enrollno` bigint NOT NULL,
  `highcase` varchar(200) NOT NULL,
  `midcase` varchar(200) NOT NULL,
  `lowcase` varchar(200) NOT NULL,
  `dayofupload` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `enrollno` bigint NOT NULL,
  `name` varchar(210) NOT NULL,
  `email` varchar(200) NOT NULL,
  `passwords` varchar(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- --------------------------------------------------------

--
-- Table structure for table `worldreport`
--

CREATE TABLE `worldreport` (
  `enrollno` bigint NOT NULL,
  `active` varchar(200) NOT NULL,
  `activestatus` varchar(100) NOT NULL,
  `recovered` varchar(255) NOT NULL,
  `recoveredstatus` varchar(100) NOT NULL,
  `newsymp` varchar(200) NOT NULL,
  `newsympstatus` varchar(100) NOT NULL,
  `deadcase` varchar(200) NOT NULL,
  `deathstatus` varchar(100) NOT NULL,
  `dayofupload` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admins`
--
ALTER TABLE `admins`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `admithistory`
--
ALTER TABLE `admithistory`
  ADD PRIMARY KEY (`enrollno`);

--
-- Indexes for table `admitreq`
--
ALTER TABLE `admitreq`
  ADD PRIMARY KEY (`enrollno`);

--
-- Indexes for table `bedadmits`
--
ALTER TABLE `bedadmits`
  ADD PRIMARY KEY (`enrollno`);

--
-- Indexes for table `dailyfreetest`
--
ALTER TABLE `dailyfreetest`
  ADD PRIMARY KEY (`enrollno`);

--
-- Indexes for table `indiareport`
--
ALTER TABLE `indiareport`
  ADD PRIMARY KEY (`enrollno`);

--
-- Indexes for table `isolation`
--
ALTER TABLE `isolation`
  ADD PRIMARY KEY (`enrollno`);

--
-- Indexes for table `patientregister`
--
ALTER TABLE `patientregister`
  ADD PRIMARY KEY (`patientid`);

--
-- Indexes for table `statereport`
--
ALTER TABLE `statereport`
  ADD PRIMARY KEY (`enrollno`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`enrollno`);

--
-- Indexes for table `worldreport`
--
ALTER TABLE `worldreport`
  ADD PRIMARY KEY (`enrollno`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admins`
--
ALTER TABLE `admins`
  MODIFY `id` bigint NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `admithistory`
--
ALTER TABLE `admithistory`
  MODIFY `enrollno` bigint NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `admitreq`
--
ALTER TABLE `admitreq`
  MODIFY `enrollno` bigint NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `bedadmits`
--
ALTER TABLE `bedadmits`
  MODIFY `enrollno` bigint NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `dailyfreetest`
--
ALTER TABLE `dailyfreetest`
  MODIFY `enrollno` bigint NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `indiareport`
--
ALTER TABLE `indiareport`
  MODIFY `enrollno` bigint NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `isolation`
--
ALTER TABLE `isolation`
  MODIFY `enrollno` bigint NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `patientregister`
--
ALTER TABLE `patientregister`
  MODIFY `patientid` bigint NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `statereport`
--
ALTER TABLE `statereport`
  MODIFY `enrollno` bigint NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `enrollno` bigint NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `worldreport`
--
ALTER TABLE `worldreport`
  MODIFY `enrollno` bigint NOT NULL AUTO_INCREMENT;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
