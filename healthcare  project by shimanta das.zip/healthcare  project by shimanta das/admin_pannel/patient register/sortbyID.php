<?php


include '/admin_pannel/connection.php';
include 'connection.php';

$patientid=  $_POST['patientid'];

$sql10="SELECT * FROM `patientregister` WHERE patientid='$patientid'";

$mysqli = $conn;

$query = $sql10;

echo '<table border="2px" cellspacing="2" cellpadding="2"> 
      <tr> 
          <td> <font face="Arial">Patient id</font> </td> 
          <td> <font face="Arial">Patient name</font> </td> 
          <td> <font face="Arial">Phone 1</font> </td> 
          <td> <font face="Arial">Phone 2</font> </td> 
          <td> <font face="Arial">Email</font> </td> 
          <td> <font face="Arial">Address</font> </td> 
          <td> <font face="Arial">Location</font> </td> 
          <td> <font face="Arial">Pincode</font> </td> 
          <td> <font face="Arial">DOB</font> </td> 
          <td> <font face="Arial">Age</font> </td> 
          <td> <font face="Arial">Image</font> </td> 
         <td> <font face="Arial">Old Symptoms</font> </td> 
 </tr>';

if ($result = $mysqli->query($query)) {
    while ($row = $result->fetch_assoc()) {
        $field1name = $row["patientid"];
        $field2name = $row["patientname"];
        $field3name = $row["phone1"];
        $field4name = $row["phone2"];
        $field5name = $row["email"];
        $field6name = $row["addr"];
        $field7name = $row["loc"];
        $field8name = $row["pincode"];
        $field9name = $row["dob"];
        $field10name = $row["age"];
        $field11ame = $row["image"];
        $field12name = $row["oldsymp"];
     

        echo '<tr> 
                  <td>'.$field1name.'</td> 
                  <td>'.$field2name.'</td> 
                  <td>'.$field3name.'</td> 
                  <td>'.$field4name.'</td> 
                  <td>'.$field5name.'</td>
                  <td>'.$field6name.'</td>
                  <td>'.$field7name.'</td>
                  <td>'.$field8name.'</td>
                  <td>'.$field9name.'</td>
                  <td>'.$field10name.'</td>
                  <td>'.'<img src="data:image/jpeg;base64,'.base64_encode($row['image']).'" height="100" width="100"/>'.'</td>
                  <td>'.$field12name.'</td>
                
                  </tr>';
    }
    $result->free();
} 


/*
redme for open-source healthcare system ...... 

* Important files configuration - 
1. in every you will find a connection.php file , now there have 4 fields - host,user,pass,db ; now for local machine 
if you use windows or either linux or mac , 
the pass(denotes password of mysql/phpmyadmin) -> will be changed according to system configuration.
2. you will find 2nd file , covidreportDBconfig.php -> this file , configuration also need to done carefully ... ok :) 

* setup & configure to our system - 
-> windows -  put all the files under C:\xampp\htdocs (xampp users only)
xampp : https://www.apachefriends.org/index.html
-> linux - /var/www/html -> put all the files .
or, xampp -> /opt/lampp/htdocs -> put all the files  [for xampp' users]
-> mac - find from youtube that how we can configure into mac as php coding files.

* for server-production deployment - 

paste all the file into /public_html directory and refresh the location in browser :) 


this code is lisenced under - GPL and GNU open-source lisence.

*/


?>


<html>
    <body>
        
    <font style="font-size:20px;">
                plz wait for 5 seconds .... 
        </font>
        <br>
        <br>

    <script>
         setTimeout(function(){
            window.location.href = '/admin_pannel/admincontrolpannel.php';
         }, 5000);
      </script>
  
  
    </body>
</html>