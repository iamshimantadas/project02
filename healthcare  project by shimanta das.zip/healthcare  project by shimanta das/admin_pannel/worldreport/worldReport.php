<?php


include '/admin_pannel/connection.php';
include 'connection.php';

$activeCase=    $_POST['activecase'];
$activeStatus=   $_POST['activestatus'];
    $recoverCase=   $_POST['reovercase'];
    $recoverStatus=   $_POST['reoverstatus'];
    $newCase=  $_POST['newcase'];
    $newcasesStatus=    $_POST['newstatus'];
    $deathcase=  $_POST['deathcase'];
    $deathstatus=    $_POST['deathstatus'];
   
    $dayofsubmit =     date("Y/m/d");

echo "<br>";
echo "active cases ".$activeCase;
echo "<br>";
echo "active case's status".$activeStatus;
echo "<br>";
echo "recover cases ".$recoverCase;
echo "<br>";
echo "recover case's status ".$recoverStatus;
echo "<br>";
echo "new cases ".$newCase;
echo "<br>";
echo "new case's status".$newcasesStatus;
echo "<br>";
echo "death cases ".$deathcase;
echo "<br>";
echo "death case's status".$deathstatus;
echo "<br>";
echo "day of submit this report ".$dayofsubmit;


$trun3 = "TRUNCATE TABLE worldreport";
 $destroyTable3 = mysqli_query($conn,$trun3);

 if ($destroyTable3) {

    echo "<br>";
    echo "old report deleted successfully ... ";
 }


$sql8="INSERT INTO `worldreport` (`enrollno`, `active`, `activestatus`, `recovered`, `recoveredstatus`, `newsymp`, `newsympstatus`, `deadcase`, `deathstatus`, `dayofupload`) VALUES (NULL, '$newCase', '$newcasesStatus', '$recoverCase', '$recoverStatus', '$newCase', '$newcasesStatus', '$deathcase', '$deathstatus', '$dayofsubmit')";
$query = mysqli_query($conn,$sql8);

if ($query) {
    echo "<br>";
    echo "wrold covid new report updates successfully ... ";
} else {
    echo "plz try again :( ";
}

/*
redme for open-source healthcare system ...... 

* Important files configuration - 
1. in every you will find a connection.php file , now there have 4 fields - host,user,pass,db ; now for local machine 
if you use windows or either linux or mac , 
the pass(denotes password of mysql/phpmyadmin) -> will be changed according to system configuration.
2. you will find 2nd file , covidreportDBconfig.php -> this file , configuration also need to done carefully ... ok :) 

* setup & configure to our system - 
-> windows -  put all the files under C:\xampp\htdocs (xampp users only)
xampp : https://www.apachefriends.org/index.html
-> linux - /var/www/html -> put all the files .
or, xampp -> /opt/lampp/htdocs -> put all the files  [for xampp' users]
-> mac - find from youtube that how we can configure into mac as php coding files.

* for server-production deployment - 

paste all the file into /public_html directory and refresh the location in browser :) 


this code is lisenced under - GPL and GNU open-source lisence.

*/

?>

<html>
    <body>
    <font style="font-size:20px;">
                plz wait for 5 seconds .... 
        </font>
        <br>
        <br>

    <script>
         setTimeout(function(){
            window.location.href = '/admin_pannel/admincontrolpannel.php';
         }, 5000);
      </script>
  
    </body>
</html>