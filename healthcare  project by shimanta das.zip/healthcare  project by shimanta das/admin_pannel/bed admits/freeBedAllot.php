<html>
<body>
<?php 
$bedno= $_POST['bedno'];

include '/admin_pannel/connection.php';
include 'connection.php';

$mysqli = $conn;


$freebedquery = "UPDATE bedadmits SET `patientname` = 'NOANY', `startdate` = '2022-01-01', `enddate` = '2022-01-01',servicetype='none' ,wardtype='none',covid19='none',bedstatus = 'FREE' WHERE `bedno` = '$bedno'";
$query = $freebedquery;
$free =  mysqli_query($conn,$query);
if ($free) {
    echo "<br>";
    echo "free bed successfully alloted .... ";
}

$afterrecord = "SELECT * FROM bedadmits WHERE bedno='$bedno'";


echo '<table border="2px" cellspacing="2" cellpadding="2"> 
      <tr> 
          <td> <font face="Arial">Enroll No</font> </td> 
          <td> <font face="Arial">Patient Name</font> </td> 
          <td> <font face="Arial">Start Date</font> </td> 
          <td> <font face="Arial">End Date</font> </td> 
          <td> <font face="Arial">Bed No Number</font> </td> 
         <td> <font face="Arial">Service Type</font> </td> 
          <td> <font face="Arial">Ward Type/day</font> </td> 
          <td> <font face="Arial">Covid-19 Status</font> </td> 
          <td> <font face="Arial">Bed Status</font> </td> 
        
          </tr>';

if ($result = $mysqli->query($afterrecord)) {
    while ($row = $result->fetch_assoc()) {
        $field1name = $row["enrollno"];
        $field2name = $row["patientname"];
        $field3name = $row["startdate"];
        $field4name = $row["enddate"];
        $field5name = $row["bedno"];
        $field6name = $row["servicetype"];
        $field7name = $row["wardtype"];
        $field8name = $row["covid19"];
        $field9name = $row["bedstatus"];
        

    echo '<tr> 
                  <td>'.$field1name.'</td> 
                  <td>'.$field2name.'</td> 
                  <td>'.$field3name.'</td> 
                  <td>'.$field4name.'</td> 
                  <td>'.$field5name.'</td>
                  <td>'.$field6name.'</td>
                  <td>'.$field7name.'</td>
                  <td>'.$field8name.'</td>
                  <td>'.$field9name.'</td>
                  </tr>';
    }
    $result->free();

    /*
redme for open-source healthcare system ...... 

* Important files configuration - 
1. in every you will find a connection.php file , now there have 4 fields - host,user,pass,db ; now for local machine 
if you use windows or either linux or mac , 
the pass(denotes password of mysql/phpmyadmin) -> will be changed according to system configuration.
2. you will find 2nd file , covidreportDBconfig.php -> this file , configuration also need to done carefully ... ok :) 

* setup & configure to our system - 
-> windows -  put all the files under C:\xampp\htdocs (xampp users only)
xampp : https://www.apachefriends.org/index.html
-> linux - /var/www/html -> put all the files .
or, xampp -> /opt/lampp/htdocs -> put all the files  [for xampp' users]
-> mac - find from youtube that how we can configure into mac as php coding files.

* for server-production deployment - 

paste all the file into /public_html directory and refresh the location in browser :) 


this code is lisenced under - GPL and GNU open-source lisence.

*/


} 
?>
</body>


<font style="font-size:20px;">
                plz wait for 5 seconds .... 
        </font>
        <br>
        <br>

    <script>
         setTimeout(function(){
            window.location.href = '/admin_pannel/admincontrolpannel.php';
         }, 5000);
      </script>
  

  
</html>