<html>
<body>
<?php 

include 'connection.php';

$mysqli = $conn;

$startdate = $_POST['startdate'];
$enddate = $_POST['enddate'];

$query = "SELECT * FROM dailyfreetest WHERE reportdate BETWEEN '$startdate' AND '$enddate'";


echo '<table border="2px" cellspacing="2" cellpadding="2"> 
      <tr> 
          <td> <font face="Arial">Enroll No</font> </td> 
          <td> <font face="Arial">Patient Name</font> </td> 
          <td> <font face="Arial">Location</font> </td> 
          <td> <font face="Arial">Pincode</font> </td> 
          <td> <font face="Arial">Phone Number</font> </td> 
         <td> <font face="Arial">Social distance</font> </td> 
          <td> <font face="Arial">Sanitize times/day</font> </td> 
          <td> <font face="Arial">Body Temp</font> </td> 
          <td> <font face="Arial">Chest Pain</font> </td> 
          <td> <font face="Arial">Report submit date</font> </td> 
        
          </tr>';

if ($result = $mysqli->query($query)) {
    while ($row = $result->fetch_assoc()) {
        $field1name = $row["enrollno"];
        $field2name = $row["patientname"];
        $field3name = $row["loc"];
        $field4name = $row["pincode"];
        $field5name = $row["phone"];
        $field6name = $row["socialdis"];
        $field7name = $row["sanitizetime"];
        $field8name = $row["bodytemp"];
        $field9name = $row["chestpain"];
        $field10name = $row["reportdate"];
     


         


        echo '<tr> 
                  <td>'.$field1name.'</td> 
                  <td>'.$field2name.'</td> 
                  <td>'.$field3name.'</td> 
                  <td>'.$field4name.'</td> 
                  <td>'.$field5name.'</td>
                  <td>'.$field6name.'</td>
                  <td>'.$field7name.'</td>
                  <td>'.$field8name.'</td>
                  <td>'.$field9name.'</td>
                  <td>'.$field10name.'</td>
                  </tr>';
    }
    $result->free();

    /*
redme for open-source healthcare system ...... 

* Important files configuration - 
1. in every you will find a connection.php file , now there have 4 fields - host,user,pass,db ; now for local machine 
if you use windows or either linux or mac , 
the pass(denotes password of mysql/phpmyadmin) -> will be changed according to system configuration.
2. you will find 2nd file , covidreportDBconfig.php -> this file , configuration also need to done carefully ... ok :) 

* setup & configure to our system - 
-> windows -  put all the files under C:\xampp\htdocs (xampp users only)
xampp : https://www.apachefriends.org/index.html
-> linux - /var/www/html -> put all the files .
or, xampp -> /opt/lampp/htdocs -> put all the files  [for xampp' users]
-> mac - find from youtube that how we can configure into mac as php coding files.

* for server-production deployment - 

paste all the file into /public_html directory and refresh the location in browser :) 


this code is lisenced under - GPL and GNU open-source lisence.

*/


} 
?>
</body>
<br>
<br>
<font style="font-size:20px;">
                plz wait for 5 seconds .... 
        </font>
        <br>
        <br>

    <script>
         setTimeout(function(){
            window.location.href = 'admincontrolpannel.php';
         }, 5000);
      </script>
     


</html>