<?php
include 'connection.php';

session_start();

if ($_SESSION["userlogin"]) {
  # code...
} else {
  echo "plz do the login";
  header("Location: userlogin.html");
}


$name=    $_POST['name'];
 $loc=   $_POST['loc'];
 $pincode=   $_POST['pincode'];
 $socaildis=   $_POST['socialdis'];
 $handwash=   $_POST['handwash'];
 $bodytemp=   $_POST['bodytemp'];
 $chestpain=   $_POST['chestpain'];
  $phone=  $_POST['phone'];
  $reportdate = date("Y/m/d") ;


  echo "Your name is :".$name;
  echo "<br>";
  echo "Your localtion :".$loc;
  echo "<br>";
  echo "Your pincode is :".$pincode;
  echo "<br>";
  echo "social distance status :".$socaildis;
  echo "<br>";
  echo "handwash times :".$handwash;
  echo "<br>";
  echo "Your body temparature :".$bodytemp;
  echo "<br>";
  echo "Your chest pian status :".$chestpain;
  echo "<br>";
  echo "Your phone number :".$phone;
  echo "<br>";



    $sql5="INSERT INTO `dailyfreetest` (`enrollno`, `patientname`, `loc`, `pincode`, `phone`, `socialdis`, `sanitizetime`, `bodytemp`, `chestpain`, `reportdate`) VALUES (NULL, '$name', '$loc', '$pincode', '$phone', '$socaildis', '$handwash', '$bodytemp', '$chestpain', '$reportdate')";
    $query =  mysqli_query($conn,$sql5);

    if ($query) {
        echo "your test report saved into our database , we will respond you soon :) ";
    } else {
       echo "plz try again :( ";
    }



/*
redme for open-source healthcare system ......

* Important files configuration -
1. in every you will find a connection.php file , now there have 4 fields - host,user,pass,db ; now for local machine
if you use windows or either linux or mac ,
the pass(denotes password of mysql/phpmyadmin) -> will be changed according to system configuration.
2. you will find 2nd file , covidreportDBconfig.php -> this file , configuration also need to done carefully ... ok :)

* setup & configure to our system -
-> windows -  put all the files under C:\xampp\htdocs (xampp users only)
xampp : https://www.apachefriends.org/index.html
-> linux - /var/www/html -> put all the files .
or, xampp -> /opt/lampp/htdocs -> put all the files  [for xampp' users]
-> mac - find from youtube that how we can configure into mac as php coding files.

* for server-production deployment -

paste all the file into /public_html directory and refresh the location in browser :)


this code is lisenced under - GPL and GNU open-source lisence.

*/

?>


<html>
    <body>
        <font style="font-size:20px;">
                plz wait for 5 seconds ....
        </font>
        <br>
        <br>

    <script>
         setTimeout(function(){
            window.location.href = 'index.php';
         }, 5000);
      </script>


    </body>
</html>
